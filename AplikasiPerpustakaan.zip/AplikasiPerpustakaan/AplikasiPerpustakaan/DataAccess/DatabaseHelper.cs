﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace AplikasiPerpustakaan.DataAccess
{
    /// <summary>
    /// Helper class untuk semua operasi database.
    /// Semua koneksi dan query lewat sini agar mudah dirawat.
    /// </summary>
    public static class DatabaseHelper
    {
        // Connection string hanya di sini saja (private readonly static)
        private static readonly string connString =
            "Server=localhost;Database=perpustakaan_db;Uid=root;Pwd=;" +
            "Convert Zero Datetime=True;Allow User Variables=True;";

        /// <summary>
        /// Mendapatkan koneksi baru
        /// </summary>
        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connString);
        }

        /// <summary>
        /// Ambil data dalam bentuk DataTable (cocok untuk DataGridView, dll.)
        /// </summary>
        public static DataTable GetData(string query, params MySqlParameter[]? parameters)
        {
            DataTable dt = new DataTable();

            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        if (parameters != null && parameters.Length > 0)
                            cmd.Parameters.AddRange(parameters);

                        using (var adapter = new MySqlDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal mengambil data:\n{ex.Message}",
                                "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dt;
        }

        /// <summary>
        /// Jalankan INSERT, UPDATE, DELETE
        /// Kembalikan jumlah baris yang terpengaruh
        /// </summary>
        public static int ExecuteNonQuery(string query, params MySqlParameter[]? parameters)
        {
            int rowsAffected = 0;

            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        if (parameters != null && parameters.Length > 0)
                            cmd.Parameters.AddRange(parameters);

                        rowsAffected = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal menjalankan perintah:\n{ex.Message}",
                                "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return rowsAffected;
        }

        /// <summary>
        /// Ambil satu nilai tunggal (misal SELECT role, COUNT(*), dll.)
        /// </summary>
        public static object? ExecuteScalar(string query, params MySqlParameter[]? parameters)
        {
            object? result = null;

            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        if (parameters != null && parameters.Length > 0)
                            cmd.Parameters.AddRange(parameters);

                        result = cmd.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gagal mengambil nilai tunggal:\n{ex.Message}",
                                "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return result;
        }
    }
}