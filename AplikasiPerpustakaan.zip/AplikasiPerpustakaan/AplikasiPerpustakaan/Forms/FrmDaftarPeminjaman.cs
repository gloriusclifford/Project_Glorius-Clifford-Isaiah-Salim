﻿using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmDaftarPeminjaman : Form
    {
        public FrmDaftarPeminjaman()
        {
            InitializeComponent();
            LoadDaftarPeminjaman();
        }

        private void LoadDaftarPeminjaman(string cari = "")
        {
            string query = @"
                SELECT 
                    p.id_peminjaman as 'ID',
                    p.nis as 'NIS',
                    a.nama as 'Nama',
                    p.nomor_buku AS 'No Buku',
                    b.judul AS 'Judul Buku',
                    p.tgl_pinjam AS 'Tgl Pinjam',
                    p.tgl_kembali AS 'Tgl Kembali Rencana'
                FROM peminjaman p
                JOIN anggota a ON p.nis = a.nis
                JOIN buku b ON p.nomor_buku = b.nomor_buku";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " where p.nis like @cari or a.nama like @cari or p.nomor_buku like @cari or b.judul like @cari";
            }

            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvPeminjaman.DataSource = dt;

                if (dgvPeminjaman.Columns.Count > 0)
                {
                    dgvPeminjaman.Columns["ID"].Width = 60;
                    dgvPeminjaman.Columns["NIS"].Width = 80;
                    dgvPeminjaman.Columns["Nama Anggota"].Width = 150;
                    dgvPeminjaman.Columns["No Buku"].Width = 80;
                    dgvPeminjaman.Columns["Judul Buku"].Width = 250;
                    dgvPeminjaman.Columns["Tgl Pinjam"].Width = 120;
                    dgvPeminjaman.Columns["Tgl Kembali Rencana"].Width = 140;
                }
            }
            catch 
            { }
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            txtCari.Text.Trim();
            LoadDaftarPeminjaman();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadDaftarPeminjaman();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
