﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmDashboardUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlHeader = new Panel();
            btnLogOut = new Button();
            lblJudul = new Label();
            picLogo = new PictureBox();
            pnlSideBar = new Panel();
            btnPengembalian = new Button();
            btnPeminjaman = new Button();
            btnDashBoard = new Button();
            lblWelcome = new Label();
            pnlMain = new Panel();
            btnRefresh = new Button();
            btnCari = new Button();
            txtCari = new TextBox();
            lblCari = new Label();
            dgvBuku = new DataGridView();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            pnlSideBar.SuspendLayout();
            pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBuku).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnLogOut);
            pnlHeader.Controls.Add(lblJudul);
            pnlHeader.Controls.Add(picLogo);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(732, 80);
            pnlHeader.TabIndex = 0;
            // 
            // btnLogOut
            // 
            btnLogOut.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogOut.BackColor = Color.Red;
            btnLogOut.FlatAppearance.BorderSize = 0;
            btnLogOut.FlatStyle = FlatStyle.Flat;
            btnLogOut.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogOut.ForeColor = Color.White;
            btnLogOut.Location = new Point(588, 25);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(120, 30);
            btnLogOut.TabIndex = 8;
            btnLogOut.Text = "Logout";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // lblJudul
            // 
            lblJudul.AutoSize = true;
            lblJudul.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = Color.White;
            lblJudul.Location = new Point(95, 20);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(242, 41);
            lblJudul.TabIndex = 1;
            lblJudul.Text = "Dashboard User";
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources.logo;
            picLogo.Location = new Point(20, 15);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(50, 50);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // pnlSideBar
            // 
            pnlSideBar.BackColor = Color.DarkBlue;
            pnlSideBar.Controls.Add(btnPengembalian);
            pnlSideBar.Controls.Add(btnPeminjaman);
            pnlSideBar.Controls.Add(btnDashBoard);
            pnlSideBar.Controls.Add(lblWelcome);
            pnlSideBar.Dock = DockStyle.Left;
            pnlSideBar.Location = new Point(0, 80);
            pnlSideBar.Name = "pnlSideBar";
            pnlSideBar.Size = new Size(250, 342);
            pnlSideBar.TabIndex = 1;
            // 
            // btnPengembalian
            // 
            btnPengembalian.BackColor = Color.CornflowerBlue;
            btnPengembalian.FlatAppearance.BorderSize = 0;
            btnPengembalian.FlatStyle = FlatStyle.Flat;
            btnPengembalian.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPengembalian.ForeColor = Color.White;
            btnPengembalian.Location = new Point(20, 202);
            btnPengembalian.Margin = new Padding(3, 0, 3, 15);
            btnPengembalian.Name = "btnPengembalian";
            btnPengembalian.Size = new Size(200, 40);
            btnPengembalian.TabIndex = 7;
            btnPengembalian.Text = "Pengembalian Buku";
            btnPengembalian.TextAlign = ContentAlignment.MiddleLeft;
            btnPengembalian.UseVisualStyleBackColor = false;
            btnPengembalian.Click += btnPengembalian_Click;
            // 
            // btnPeminjaman
            // 
            btnPeminjaman.BackColor = Color.CornflowerBlue;
            btnPeminjaman.FlatAppearance.BorderSize = 0;
            btnPeminjaman.FlatStyle = FlatStyle.Flat;
            btnPeminjaman.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPeminjaman.ForeColor = Color.White;
            btnPeminjaman.Location = new Point(20, 147);
            btnPeminjaman.Margin = new Padding(3, 0, 3, 15);
            btnPeminjaman.Name = "btnPeminjaman";
            btnPeminjaman.Size = new Size(200, 40);
            btnPeminjaman.TabIndex = 6;
            btnPeminjaman.Text = "Peminjaman Buku";
            btnPeminjaman.TextAlign = ContentAlignment.MiddleLeft;
            btnPeminjaman.UseVisualStyleBackColor = false;
            btnPeminjaman.Click += btnPeminjaman_Click;
            // 
            // btnDashBoard
            // 
            btnDashBoard.BackColor = Color.CornflowerBlue;
            btnDashBoard.FlatAppearance.BorderSize = 0;
            btnDashBoard.FlatStyle = FlatStyle.Flat;
            btnDashBoard.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashBoard.ForeColor = Color.White;
            btnDashBoard.Location = new Point(20, 92);
            btnDashBoard.Margin = new Padding(3, 0, 3, 15);
            btnDashBoard.Name = "btnDashBoard";
            btnDashBoard.Size = new Size(200, 40);
            btnDashBoard.TabIndex = 5;
            btnDashBoard.Text = "DashBoard Utama";
            btnDashBoard.TextAlign = ContentAlignment.MiddleLeft;
            btnDashBoard.UseVisualStyleBackColor = false;
            btnDashBoard.Click += btnDashBoard_Click;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcome.ForeColor = SystemColors.Control;
            lblWelcome.Location = new Point(20, 30);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(125, 31);
            lblWelcome.TabIndex = 4;
            lblWelcome.Text = "WELCOME";
            lblWelcome.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlMain
            // 
            pnlMain.Controls.Add(btnRefresh);
            pnlMain.Controls.Add(btnCari);
            pnlMain.Controls.Add(txtCari);
            pnlMain.Controls.Add(lblCari);
            pnlMain.Controls.Add(dgvBuku);
            pnlMain.Dock = DockStyle.Fill;
            pnlMain.Location = new Point(250, 80);
            pnlMain.Name = "pnlMain";
            pnlMain.Size = new Size(482, 342);
            pnlMain.TabIndex = 2;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(382, 27);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(76, 30);
            btnRefresh.TabIndex = 8;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(311, 27);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(65, 30);
            btnCari.TabIndex = 7;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // txtCari
            // 
            txtCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCari.Location = new Point(89, 27);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(196, 30);
            txtCari.TabIndex = 6;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(40, 30);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(42, 23);
            lblCari.TabIndex = 5;
            lblCari.Text = "Cari";
            // 
            // dgvBuku
            // 
            dgvBuku.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBuku.Location = new Point(40, 60);
            dgvBuku.Name = "dgvBuku";
            dgvBuku.RowHeadersWidth = 51;
            dgvBuku.Size = new Size(418, 247);
            dgvBuku.TabIndex = 0;
            // 
            // FrmDashboardUser
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(732, 422);
            Controls.Add(pnlMain);
            Controls.Add(pnlSideBar);
            Controls.Add(pnlHeader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmDashboardUser";
            StartPosition = FormStartPosition.CenterScreen;
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlSideBar.ResumeLayout(false);
            pnlSideBar.PerformLayout();
            pnlMain.ResumeLayout(false);
            pnlMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Label lblJudul;
        private PictureBox picLogo;
        private Panel pnlSideBar;
        private Panel pnlMain;
        private Label lblWelcome;
        private Button btnDashBoard;
        private Button btnPengembalian;
        private Button btnPeminjaman;
        private Button btnLogOut;
        private DataGridView dgvBuku;
        private Label lblCari;
        private TextBox txtCari;
        private Button btnCari;
        private Button btnRefresh;
    }
}