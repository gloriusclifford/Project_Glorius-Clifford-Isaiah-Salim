using AplikasiPerpustakaan.Forms;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using AplikasiPerpustakaan.DataAccess;

namespace AplikasiPerpustakaan
{
    public partial class FrmLogin : Form
    {
        public static string CurrentUserNIS { get; set; }

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username dan Passowrd Harus Diisi!!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Focus();
                return;
            }

            // Query dengan JOIN ke tabel anggota untuk ambil nis
            string query = @"
                SELECT 
                    password, 
                    role, 
                    nis 
                FROM users 
                WHERE username = @username";

            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@username", username));

                if (dt.Rows.Count > 0)
                {
                    string storedHash = dt.Rows[0]["password"].ToString();
                    string role = dt.Rows[0]["role"].ToString().Trim();

                    if (BCrypt.Net.BCrypt.Verify(password, storedHash))
                    {
                        // Ambil nis dari tabel anggota (bisa null kalau role Admin)
                        CurrentUserNIS = dt.Rows[0]["nis"]?.ToString() ?? "";

                        MessageBox.Show("Login berhasil sebagai " + role, "Sukses");

                        this.Hide();

                        if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            new FrmDashboardAdmin().Show();
                        }
                        else
                        {
                            new FrmDashboardUser().Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username dan Password Salah");
                        txtUsername.Clear();
                        txtPassword.Clear();
                        txtUsername.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Username dan Password Salah");
                    txtUsername.Clear();
                    txtPassword.Clear();
                    txtUsername.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saat menambahkan buku:\n" + ex.Message, "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            txtUsername.BackColor = SystemColors.Window;
            txtPassword.BackColor = SystemColors.Window;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            txtUsername.BackColor = SystemColors.Window;
            txtPassword.BackColor = SystemColors.Window;
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtPassword.UseSystemPasswordChar = true;
            }
            txtPassword.Refresh();
            txtPassword.Focus();
        }

        private void btnDaftar_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmRegister())
            {
                frm.ShowDialog();
            }
            txtUsername.Focus();
        }

        private void FrmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}