﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmPeminjaman : Form
    {
        private string nisUser, nomorBukuDipilih = "";


        public FrmPeminjaman(string nis)
        {
            InitializeComponent();
            LoadDaftarBuku();

            nisUser = nis;
            txtNIS.Text = nisUser;

            dtpPinjam.MinDate = DateTime.Today;
            dtpPinjam.Value = DateTime.Today;
            dtpPengembalian.Value = DateTime.Today.AddDays(7);
            dtpPengembalian.MinDate = DateTime.Today.AddDays(1);

            dtpPinjam.ValueChanged += (s, e) =>
            {
                dtpPengembalian.MinDate = dtpPinjam.Value.AddDays(1);
                if (dtpPengembalian.Value < dtpPengembalian.MinDate)
                    dtpPengembalian.Value = dtpPengembalian.MinDate;
            };
        }

        private void LoadDaftarBuku(string cari = "")
        {
            string query = @"
                SELECT
                    nomor_buku AS 'No Buku',
                    judul AS 'Judul',
                    pengarang AS 'Pengarang',
                    genre AS 'Genre',
                    status AS 'Status'
                FROM buku";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " WHERE judul LIKE @cari OR pengarang LIKE @cari OR genre LIKE @cari";
            }

            DataTable dt = null;

            try
            {
                dt = DatabaseHelper.GetData(query, new MySqlParameter("@cari", "%" + cari + "%"));

                dgvBuku.DataSource = dt ?? new DataTable();
            }
            catch
            { }

            if (dgvBuku.Columns.Count > 0)
            {
                dgvBuku.Columns["No Buku"].Width = 80;
                dgvBuku.Columns["Judul"].Width = 250;
                dgvBuku.Columns["Pengarang"].Width = 200;
                dgvBuku.Columns["Genre"].Width = 120;
                dgvBuku.Columns["Status"].Width = 100;

            }
            foreach (DataGridViewRow row in dgvBuku.Rows)
            {
                string status = row.Cells["Status"].Value?.ToString()?.Trim();

                if (status == "Tersedia")
                {
                    row.DefaultCellStyle.BackColor = Color.LightGreen;
                    row.DefaultCellStyle.ForeColor = Color.Black;
                }
                else if (status == "Dipinjam")
                {
                    row.DefaultCellStyle.BackColor = Color.Orange;
                    row.DefaultCellStyle.ForeColor = Color.Black;
                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPinjam_Click(object sender, EventArgs e)
        {
            string nis = txtNIS.Text.Trim();
            string nomorBuku = txtNomBuk.Text.Trim();
            DateTime tglPinjam = dtpPinjam.Value.Date;
            DateTime tglKembali = dtpPengembalian.Value.Date;

            //Validasi
            if (string.IsNullOrEmpty(nis) || string.IsNullOrEmpty(nomorBuku))
            {
                MessageBox.Show("NIS dan Nomor Buku harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cekBuku = "select status from buku where nomor_buku = @nomorBuku";
            object status = DatabaseHelper.ExecuteScalar(cekBuku, new MySqlParameter("@nomorBuku", nomorBuku));

            if (status == null || status.ToString() != "Tersedia")
            {
                MessageBox.Show("Buku tidak tersedia", "Gagal Pinjam", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string qInsert = @"
                INSERT INTO peminjaman (nis, nomor_buku, tgl_pinjam, tgl_kembali)
                VALUES (@nis, @nomorBuku, @tglPinjam, @tglKembali)";

            int rows = DatabaseHelper.ExecuteNonQuery(qInsert,
                new MySqlParameter("@nis", nis),
                new MySqlParameter("@nomorBuku", nomorBuku),
                new MySqlParameter("@tglPinjam", tglPinjam),
                new MySqlParameter("@tglKembali", tglKembali));

            if (rows > 0)
            {
                string qUpdate = "update buku set status = 'Dipinjam' where nomor_buku = @nomorBuku";
                DatabaseHelper.ExecuteNonQuery(qUpdate, new MySqlParameter("@nomorBuku", nomorBuku));

                MessageBox.Show("Peminjaman Berhasil: \nBuku telah dipinjam", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Gagal meminjam buku", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string cari = txtCari.Text.Trim();
            LoadDaftarBuku(cari);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadDaftarBuku();
        }

        private void txtNomBuk_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvBuku_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBuku.SelectedRows.Count > 0)
            {
                var row = dgvBuku.SelectedRows[0];

                nomorBukuDipilih = row.Cells["No Buku"].Value.ToString();
                txtNomBuk.Text = nomorBukuDipilih;
                txtNomBuk.ReadOnly = true;
            }
        }
    }
}
