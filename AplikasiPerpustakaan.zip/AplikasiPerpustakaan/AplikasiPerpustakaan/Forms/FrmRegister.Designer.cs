﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblJudul = new Label();
            lblNIS = new Label();
            lblNama = new Label();
            lblAlamat = new Label();
            lblTelepon = new Label();
            lblKelas = new Label();
            txtNIS = new TextBox();
            txtNama = new TextBox();
            txtAlamat = new TextBox();
            txtTelepon = new TextBox();
            txtKelas = new TextBox();
            btnDaftar = new Button();
            txtUsername = new TextBox();
            lblUsername = new Label();
            txtPassword = new TextBox();
            lblPassword = new Label();
            chkShowPassword = new CheckBox();
            lblError = new Label();
            pnlHalaman = new Panel();
            btnBack = new Button();
            pnlHalaman.SuspendLayout();
            SuspendLayout();
            // 
            // lblJudul
            // 
            lblJudul.AutoSize = true;
            lblJudul.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = Color.White;
            lblJudul.Location = new Point(3, 208);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(261, 28);
            lblJudul.TabIndex = 0;
            lblJudul.Text = "PENDAFTARAN ANGGOTA";
            lblJudul.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblNIS
            // 
            lblNIS.AutoSize = true;
            lblNIS.Location = new Point(27, 22);
            lblNIS.Name = "lblNIS";
            lblNIS.Size = new Size(32, 20);
            lblNIS.TabIndex = 1;
            lblNIS.Text = "NIS";
            lblNIS.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblNama
            // 
            lblNama.AutoSize = true;
            lblNama.Location = new Point(27, 84);
            lblNama.Name = "lblNama";
            lblNama.Size = new Size(53, 20);
            lblNama.TabIndex = 2;
            lblNama.Text = "NAMA";
            lblNama.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblAlamat
            // 
            lblAlamat.AutoSize = true;
            lblAlamat.Location = new Point(27, 146);
            lblAlamat.Name = "lblAlamat";
            lblAlamat.Size = new Size(57, 20);
            lblAlamat.TabIndex = 3;
            lblAlamat.Text = "Alamat";
            lblAlamat.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblTelepon
            // 
            lblTelepon.AutoSize = true;
            lblTelepon.Location = new Point(27, 208);
            lblTelepon.Name = "lblTelepon";
            lblTelepon.Size = new Size(62, 20);
            lblTelepon.TabIndex = 4;
            lblTelepon.Text = "Telepon";
            lblTelepon.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblKelas
            // 
            lblKelas.AutoSize = true;
            lblKelas.Location = new Point(27, 270);
            lblKelas.Name = "lblKelas";
            lblKelas.Size = new Size(44, 20);
            lblKelas.TabIndex = 5;
            lblKelas.Text = "Kelas";
            lblKelas.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtNIS
            // 
            txtNIS.Location = new Point(27, 45);
            txtNIS.Name = "txtNIS";
            txtNIS.Size = new Size(200, 27);
            txtNIS.TabIndex = 8;
            // 
            // txtNama
            // 
            txtNama.Location = new Point(27, 107);
            txtNama.Name = "txtNama";
            txtNama.Size = new Size(200, 27);
            txtNama.TabIndex = 9;
            // 
            // txtAlamat
            // 
            txtAlamat.Location = new Point(27, 169);
            txtAlamat.Name = "txtAlamat";
            txtAlamat.Size = new Size(200, 27);
            txtAlamat.TabIndex = 10;
            // 
            // txtTelepon
            // 
            txtTelepon.Location = new Point(27, 231);
            txtTelepon.Name = "txtTelepon";
            txtTelepon.Size = new Size(200, 27);
            txtTelepon.TabIndex = 11;
            // 
            // txtKelas
            // 
            txtKelas.Location = new Point(27, 293);
            txtKelas.Name = "txtKelas";
            txtKelas.Size = new Size(200, 27);
            txtKelas.TabIndex = 12;
            // 
            // btnDaftar
            // 
            btnDaftar.BackColor = SystemColors.ActiveCaption;
            btnDaftar.FlatAppearance.BorderSize = 0;
            btnDaftar.FlatStyle = FlatStyle.Flat;
            btnDaftar.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDaftar.ForeColor = Color.Black;
            btnDaftar.Location = new Point(89, 261);
            btnDaftar.Name = "btnDaftar";
            btnDaftar.Size = new Size(94, 29);
            btnDaftar.TabIndex = 13;
            btnDaftar.Text = "Daftar";
            btnDaftar.UseVisualStyleBackColor = false;
            btnDaftar.Click += btnDaftar_Click;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(27, 357);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(200, 27);
            txtUsername.TabIndex = 15;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(27, 334);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(75, 20);
            lblUsername.TabIndex = 14;
            lblUsername.Text = "Username";
            lblUsername.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(27, 420);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(200, 27);
            txtPassword.TabIndex = 17;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(27, 397);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(70, 20);
            lblPassword.TabIndex = 16;
            lblPassword.Text = "Password";
            lblPassword.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // chkShowPassword
            // 
            chkShowPassword.AutoSize = true;
            chkShowPassword.Font = new Font("SF Pro Display", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkShowPassword.Location = new Point(27, 462);
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.Size = new Size(116, 20);
            chkShowPassword.TabIndex = 18;
            chkShowPassword.Text = "Show Password";
            chkShowPassword.UseVisualStyleBackColor = true;
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChanged;
            // 
            // lblError
            // 
            lblError.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblError.AutoSize = true;
            lblError.FlatStyle = FlatStyle.Flat;
            lblError.Font = new Font("SF Pro Display", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblError.ForeColor = Color.Red;
            lblError.Location = new Point(3, 172);
            lblError.Name = "lblError";
            lblError.Size = new Size(0, 20);
            lblError.TabIndex = 19;
            lblError.TextAlign = ContentAlignment.MiddleCenter;
            lblError.Visible = false;
            // 
            // pnlHalaman
            // 
            pnlHalaman.BackColor = Color.Navy;
            pnlHalaman.Controls.Add(btnBack);
            pnlHalaman.Controls.Add(lblJudul);
            pnlHalaman.Controls.Add(lblError);
            pnlHalaman.Controls.Add(btnDaftar);
            pnlHalaman.Dock = DockStyle.Right;
            pnlHalaman.Location = new Point(270, 0);
            pnlHalaman.Name = "pnlHalaman";
            pnlHalaman.Size = new Size(262, 503);
            pnlHalaman.TabIndex = 20;
            // 
            // btnBack
            // 
            btnBack.BackColor = SystemColors.ActiveCaption;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.Black;
            btnBack.Location = new Point(89, 296);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 29);
            btnBack.TabIndex = 20;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // FrmRegister
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(532, 503);
            Controls.Add(pnlHalaman);
            Controls.Add(chkShowPassword);
            Controls.Add(txtPassword);
            Controls.Add(lblPassword);
            Controls.Add(txtUsername);
            Controls.Add(lblUsername);
            Controls.Add(txtKelas);
            Controls.Add(txtTelepon);
            Controls.Add(txtAlamat);
            Controls.Add(txtNama);
            Controls.Add(txtNIS);
            Controls.Add(lblKelas);
            Controls.Add(lblTelepon);
            Controls.Add(lblAlamat);
            Controls.Add(lblNama);
            Controls.Add(lblNIS);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "FrmRegister";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmRegister";
            pnlHalaman.ResumeLayout(false);
            pnlHalaman.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblJudul;
        private Label lblNIS;
        private Label lblNama;
        private Label lblAlamat;
        private Label lblTelepon;
        private Label lblKelas;
        private TextBox txtNIS;
        private TextBox txtNama;
        private TextBox txtAlamat;
        private TextBox txtTelepon;
        private TextBox txtKelas;
        private Button btnDaftar;
        private TextBox txtUsername;
        private Label lblUsername;
        private TextBox txtPassword;
        private Label lblPassword;
        private CheckBox chkShowPassword;
        private Label lblError;
        private Panel pnlHalaman;
        private Button btnBack;
    }
}