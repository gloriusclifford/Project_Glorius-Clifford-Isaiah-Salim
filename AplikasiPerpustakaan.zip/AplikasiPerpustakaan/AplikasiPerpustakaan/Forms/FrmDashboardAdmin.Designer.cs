﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmDashboardAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlHeader = new Panel();
            btnLogOut = new Button();
            lblJudul = new Label();
            picLogo = new PictureBox();
            pnlSideBar = new Panel();
            btnPeminjaman = new Button();
            btnKelolaAnggota = new Button();
            btnKelolaBuku = new Button();
            lblWelcome = new Label();
            pnlContent = new Panel();
            btnRefresh = new Button();
            btnCari = new Button();
            txtCari = new TextBox();
            lblCari = new Label();
            dgvTabel = new DataGridView();
            pnlJumlah = new Panel();
            lblJumlah = new Label();
            lblJumlahBuku = new Label();
            pnlTersedia = new Panel();
            lblBukuTersedia = new Label();
            lblTersedia = new Label();
            pnlAnggota = new Panel();
            lblAnggota = new Label();
            lblJumlahAnggota = new Label();
            pnlDipinjam = new Panel();
            lblDipinjam = new Label();
            lblBukuDipinjam = new Label();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            pnlSideBar.SuspendLayout();
            pnlContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvTabel).BeginInit();
            pnlJumlah.SuspendLayout();
            pnlTersedia.SuspendLayout();
            pnlAnggota.SuspendLayout();
            pnlDipinjam.SuspendLayout();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnLogOut);
            pnlHeader.Controls.Add(lblJudul);
            pnlHeader.Controls.Add(picLogo);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(982, 80);
            pnlHeader.TabIndex = 0;
            // 
            // btnLogOut
            // 
            btnLogOut.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogOut.BackColor = Color.Red;
            btnLogOut.FlatAppearance.BorderSize = 0;
            btnLogOut.FlatStyle = FlatStyle.Flat;
            btnLogOut.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogOut.ForeColor = Color.White;
            btnLogOut.Location = new Point(836, 28);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(120, 30);
            btnLogOut.TabIndex = 2;
            btnLogOut.Text = "Logout";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // lblJudul
            // 
            lblJudul.AutoSize = true;
            lblJudul.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = SystemColors.Control;
            lblJudul.Location = new Point(90, 20);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(300, 38);
            lblJudul.TabIndex = 1;
            lblJudul.Text = "DASHBOARD ADMIN";
            // 
            // picLogo
            // 
            picLogo.Image = Properties.Resources.logo;
            picLogo.Location = new Point(20, 15);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(50, 50);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 0;
            picLogo.TabStop = false;
            // 
            // pnlSideBar
            // 
            pnlSideBar.BackColor = Color.DarkBlue;
            pnlSideBar.Controls.Add(btnPeminjaman);
            pnlSideBar.Controls.Add(btnKelolaAnggota);
            pnlSideBar.Controls.Add(btnKelolaBuku);
            pnlSideBar.Controls.Add(lblWelcome);
            pnlSideBar.Dock = DockStyle.Left;
            pnlSideBar.Location = new Point(0, 80);
            pnlSideBar.Name = "pnlSideBar";
            pnlSideBar.Size = new Size(250, 473);
            pnlSideBar.TabIndex = 1;
            // 
            // btnPeminjaman
            // 
            btnPeminjaman.BackColor = Color.CornflowerBlue;
            btnPeminjaman.FlatAppearance.BorderSize = 0;
            btnPeminjaman.FlatStyle = FlatStyle.Flat;
            btnPeminjaman.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPeminjaman.ForeColor = Color.White;
            btnPeminjaman.Location = new Point(20, 271);
            btnPeminjaman.Margin = new Padding(3, 0, 3, 15);
            btnPeminjaman.Name = "btnPeminjaman";
            btnPeminjaman.Padding = new Padding(20, 0, 0, 0);
            btnPeminjaman.Size = new Size(200, 40);
            btnPeminjaman.TabIndex = 7;
            btnPeminjaman.Text = "Daftar Peminjaman";
            btnPeminjaman.TextAlign = ContentAlignment.MiddleLeft;
            btnPeminjaman.UseVisualStyleBackColor = false;
            btnPeminjaman.Click += btnPeminjaman_Click;
            // 
            // btnKelolaAnggota
            // 
            btnKelolaAnggota.BackColor = Color.CornflowerBlue;
            btnKelolaAnggota.FlatAppearance.BorderSize = 0;
            btnKelolaAnggota.FlatStyle = FlatStyle.Flat;
            btnKelolaAnggota.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnKelolaAnggota.ForeColor = Color.White;
            btnKelolaAnggota.Location = new Point(20, 216);
            btnKelolaAnggota.Margin = new Padding(3, 0, 3, 15);
            btnKelolaAnggota.Name = "btnKelolaAnggota";
            btnKelolaAnggota.Padding = new Padding(20, 0, 0, 0);
            btnKelolaAnggota.Size = new Size(200, 40);
            btnKelolaAnggota.TabIndex = 6;
            btnKelolaAnggota.Text = "Kelola Anggota";
            btnKelolaAnggota.TextAlign = ContentAlignment.MiddleLeft;
            btnKelolaAnggota.UseVisualStyleBackColor = false;
            btnKelolaAnggota.Click += btnKelolaAnggota_Click;
            // 
            // btnKelolaBuku
            // 
            btnKelolaBuku.BackColor = Color.CornflowerBlue;
            btnKelolaBuku.FlatAppearance.BorderSize = 0;
            btnKelolaBuku.FlatStyle = FlatStyle.Flat;
            btnKelolaBuku.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnKelolaBuku.ForeColor = Color.White;
            btnKelolaBuku.Location = new Point(20, 161);
            btnKelolaBuku.Margin = new Padding(3, 0, 3, 15);
            btnKelolaBuku.Name = "btnKelolaBuku";
            btnKelolaBuku.Padding = new Padding(20, 0, 0, 0);
            btnKelolaBuku.Size = new Size(200, 40);
            btnKelolaBuku.TabIndex = 5;
            btnKelolaBuku.Text = "Kelola Buku";
            btnKelolaBuku.TextAlign = ContentAlignment.MiddleLeft;
            btnKelolaBuku.UseVisualStyleBackColor = false;
            btnKelolaBuku.Click += btnKelolaBuku_Click;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcome.ForeColor = SystemColors.Control;
            lblWelcome.Location = new Point(20, 43);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(153, 38);
            lblWelcome.TabIndex = 3;
            lblWelcome.Text = "WELCOME";
            lblWelcome.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlContent
            // 
            pnlContent.AutoSize = true;
            pnlContent.Controls.Add(btnRefresh);
            pnlContent.Controls.Add(btnCari);
            pnlContent.Controls.Add(txtCari);
            pnlContent.Controls.Add(lblCari);
            pnlContent.Controls.Add(dgvTabel);
            pnlContent.Controls.Add(pnlJumlah);
            pnlContent.Controls.Add(pnlTersedia);
            pnlContent.Controls.Add(pnlAnggota);
            pnlContent.Controls.Add(pnlDipinjam);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(250, 80);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(732, 473);
            pnlContent.TabIndex = 2;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(637, 127);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(76, 30);
            btnRefresh.TabIndex = 7;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(566, 127);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(65, 30);
            btnCari.TabIndex = 6;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // txtCari
            // 
            txtCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCari.Location = new Point(75, 125);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(375, 30);
            txtCari.TabIndex = 5;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(23, 125);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(46, 28);
            lblCari.TabIndex = 4;
            lblCari.Text = "Cari";
            // 
            // dgvTabel
            // 
            dgvTabel.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTabel.Location = new Point(23, 162);
            dgvTabel.Name = "dgvTabel";
            dgvTabel.ReadOnly = true;
            dgvTabel.RowHeadersWidth = 51;
            dgvTabel.Size = new Size(690, 274);
            dgvTabel.TabIndex = 3;
            dgvTabel.CellContentClick += dataGridView1_CellContentClick;
            // 
            // pnlJumlah
            // 
            pnlJumlah.BackColor = SystemColors.GradientActiveCaption;
            pnlJumlah.Controls.Add(lblJumlah);
            pnlJumlah.Controls.Add(lblJumlahBuku);
            pnlJumlah.Location = new Point(546, 43);
            pnlJumlah.Name = "pnlJumlah";
            pnlJumlah.Size = new Size(168, 59);
            pnlJumlah.TabIndex = 2;
            // 
            // lblJumlah
            // 
            lblJumlah.AutoSize = true;
            lblJumlah.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblJumlah.Location = new Point(5, 30);
            lblJumlah.Name = "lblJumlah";
            lblJumlah.Size = new Size(0, 23);
            lblJumlah.TabIndex = 3;
            lblJumlah.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblJumlahBuku
            // 
            lblJumlahBuku.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            lblJumlahBuku.AutoSize = true;
            lblJumlahBuku.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJumlahBuku.Location = new Point(3, 0);
            lblJumlahBuku.Name = "lblJumlahBuku";
            lblJumlahBuku.Size = new Size(134, 28);
            lblJumlahBuku.TabIndex = 3;
            lblJumlahBuku.Text = "Jumlah Buku";
            lblJumlahBuku.TextAlign = ContentAlignment.TopCenter;
            // 
            // pnlTersedia
            // 
            pnlTersedia.BackColor = SystemColors.GradientActiveCaption;
            pnlTersedia.Controls.Add(lblBukuTersedia);
            pnlTersedia.Controls.Add(lblTersedia);
            pnlTersedia.Location = new Point(24, 43);
            pnlTersedia.Name = "pnlTersedia";
            pnlTersedia.Size = new Size(168, 59);
            pnlTersedia.TabIndex = 1;
            // 
            // lblBukuTersedia
            // 
            lblBukuTersedia.AutoSize = true;
            lblBukuTersedia.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBukuTersedia.Location = new Point(5, 30);
            lblBukuTersedia.Name = "lblBukuTersedia";
            lblBukuTersedia.Size = new Size(0, 23);
            lblBukuTersedia.TabIndex = 1;
            lblBukuTersedia.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblTersedia
            // 
            lblTersedia.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            lblTersedia.AutoSize = true;
            lblTersedia.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTersedia.Location = new Point(3, 0);
            lblTersedia.Name = "lblTersedia";
            lblTersedia.Size = new Size(144, 28);
            lblTersedia.TabIndex = 0;
            lblTersedia.Text = "Buku Tersedia";
            lblTersedia.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlAnggota
            // 
            pnlAnggota.BackColor = SystemColors.GradientActiveCaption;
            pnlAnggota.Controls.Add(lblAnggota);
            pnlAnggota.Controls.Add(lblJumlahAnggota);
            pnlAnggota.Location = new Point(198, 43);
            pnlAnggota.Name = "pnlAnggota";
            pnlAnggota.Size = new Size(168, 59);
            pnlAnggota.TabIndex = 1;
            // 
            // lblAnggota
            // 
            lblAnggota.AutoSize = true;
            lblAnggota.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAnggota.Location = new Point(5, 30);
            lblAnggota.Name = "lblAnggota";
            lblAnggota.Size = new Size(0, 23);
            lblAnggota.TabIndex = 2;
            lblAnggota.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblJumlahAnggota
            // 
            lblJumlahAnggota.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            lblJumlahAnggota.AutoSize = true;
            lblJumlahAnggota.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJumlahAnggota.Location = new Point(3, 0);
            lblJumlahAnggota.Name = "lblJumlahAnggota";
            lblJumlahAnggota.Size = new Size(167, 28);
            lblJumlahAnggota.TabIndex = 1;
            lblJumlahAnggota.Text = "Jumlah Anggota";
            lblJumlahAnggota.TextAlign = ContentAlignment.TopCenter;
            // 
            // pnlDipinjam
            // 
            pnlDipinjam.BackColor = SystemColors.GradientActiveCaption;
            pnlDipinjam.Controls.Add(lblDipinjam);
            pnlDipinjam.Controls.Add(lblBukuDipinjam);
            pnlDipinjam.Location = new Point(372, 43);
            pnlDipinjam.Name = "pnlDipinjam";
            pnlDipinjam.Size = new Size(168, 59);
            pnlDipinjam.TabIndex = 0;
            // 
            // lblDipinjam
            // 
            lblDipinjam.AutoSize = true;
            lblDipinjam.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDipinjam.Location = new Point(5, 30);
            lblDipinjam.Name = "lblDipinjam";
            lblDipinjam.Size = new Size(0, 23);
            lblDipinjam.TabIndex = 3;
            lblDipinjam.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblBukuDipinjam
            // 
            lblBukuDipinjam.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            lblBukuDipinjam.AutoSize = true;
            lblBukuDipinjam.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblBukuDipinjam.Location = new Point(3, 0);
            lblBukuDipinjam.Name = "lblBukuDipinjam";
            lblBukuDipinjam.Size = new Size(152, 28);
            lblBukuDipinjam.TabIndex = 2;
            lblBukuDipinjam.Text = "Buku Dipinjam";
            lblBukuDipinjam.TextAlign = ContentAlignment.TopCenter;
            // 
            // FrmDashboardAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 553);
            Controls.Add(pnlContent);
            Controls.Add(pnlSideBar);
            Controls.Add(pnlHeader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmDashboardAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmDashboardAdmin";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlSideBar.ResumeLayout(false);
            pnlSideBar.PerformLayout();
            pnlContent.ResumeLayout(false);
            pnlContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvTabel).EndInit();
            pnlJumlah.ResumeLayout(false);
            pnlJumlah.PerformLayout();
            pnlTersedia.ResumeLayout(false);
            pnlTersedia.PerformLayout();
            pnlAnggota.ResumeLayout(false);
            pnlAnggota.PerformLayout();
            pnlDipinjam.ResumeLayout(false);
            pnlDipinjam.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlHeader;
        private Panel pnlSideBar;
        private PictureBox picLogo;
        private Panel pnlContent;
        private Label lblJudul;
        private Button btnLogOut;
        private Label lblWelcome;
        private Button btnKelolaBuku;
        private Button btnPeminjaman;
        private Button btnKelolaAnggota;
        private Panel pnlDipinjam;
        private Panel pnlTersedia;
        private Panel pnlAnggota;
        private DataGridView dgvTabel;
        private Panel pnlJumlah;
        private Label lblJumlahBuku;
        private Label lblTersedia;
        private Label lblJumlahAnggota;
        private Label lblBukuDipinjam;
        private Label lblBukuTersedia;
        private Label lblJumlah;
        private Label lblAnggota;
        private Label lblDipinjam;
        private Label lblCari;
        private Button btnRefresh;
        private Button btnCari;
        private TextBox txtCari;
    }
}