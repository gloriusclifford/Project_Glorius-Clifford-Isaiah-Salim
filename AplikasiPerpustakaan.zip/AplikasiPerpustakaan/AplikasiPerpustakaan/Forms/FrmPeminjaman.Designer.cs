﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmPeminjaman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPeminjaman));
            pnlHeader = new Panel();
            btnkembali = new Button();
            picLogo = new PictureBox();
            lblJudul = new Label();
            pnlContent = new Panel();
            btnRefresh = new Button();
            btnCari = new Button();
            txtCari = new TextBox();
            btnBack = new Button();
            btnPinjam = new Button();
            lblCari = new Label();
            dtpPengembalian = new DateTimePicker();
            lblTanggalKembali = new Label();
            txtNomBuk = new TextBox();
            txtNIS = new TextBox();
            dtpPinjam = new DateTimePicker();
            lblTangganPinjam = new Label();
            lblNomorBuku = new Label();
            lblNis = new Label();
            dgvBuku = new DataGridView();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            pnlContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBuku).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnkembali);
            pnlHeader.Controls.Add(picLogo);
            pnlHeader.Controls.Add(lblJudul);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(732, 80);
            pnlHeader.TabIndex = 0;
            // 
            // btnkembali
            // 
            btnkembali.BackColor = Color.DeepSkyBlue;
            btnkembali.FlatAppearance.BorderSize = 0;
            btnkembali.FlatStyle = FlatStyle.Flat;
            btnkembali.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnkembali.ForeColor = SystemColors.Control;
            btnkembali.Location = new Point(613, 28);
            btnkembali.Name = "btnkembali";
            btnkembali.Size = new Size(94, 30);
            btnkembali.TabIndex = 2;
            btnkembali.Text = "Back";
            btnkembali.UseVisualStyleBackColor = false;
            btnkembali.Click += button1_Click;
            // 
            // picLogo
            // 
            picLogo.Image = (Image)resources.GetObject("picLogo.Image");
            picLogo.Location = new Point(40, 15);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(50, 50);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 1;
            picLogo.TabStop = false;
            // 
            // lblJudul
            // 
            lblJudul.AutoSize = true;
            lblJudul.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = Color.White;
            lblJudul.Location = new Point(96, 20);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(180, 38);
            lblJudul.TabIndex = 0;
            lblJudul.Text = "Peminjaman";
            // 
            // pnlContent
            // 
            pnlContent.Controls.Add(btnRefresh);
            pnlContent.Controls.Add(btnCari);
            pnlContent.Controls.Add(txtCari);
            pnlContent.Controls.Add(btnBack);
            pnlContent.Controls.Add(btnPinjam);
            pnlContent.Controls.Add(lblCari);
            pnlContent.Controls.Add(dtpPengembalian);
            pnlContent.Controls.Add(lblTanggalKembali);
            pnlContent.Controls.Add(txtNomBuk);
            pnlContent.Controls.Add(txtNIS);
            pnlContent.Controls.Add(dtpPinjam);
            pnlContent.Controls.Add(lblTangganPinjam);
            pnlContent.Controls.Add(lblNomorBuku);
            pnlContent.Controls.Add(lblNis);
            pnlContent.Controls.Add(dgvBuku);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(0, 80);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(732, 342);
            pnlContent.TabIndex = 2;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(641, 37);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(66, 29);
            btnRefresh.TabIndex = 14;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(580, 37);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(55, 29);
            btnCari.TabIndex = 13;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // txtCari
            // 
            txtCari.Location = new Point(363, 38);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(211, 27);
            txtCari.TabIndex = 12;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.PowderBlue;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Location = new Point(119, 287);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(73, 29);
            btnBack.TabIndex = 11;
            btnBack.Text = "Kembali";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // btnPinjam
            // 
            btnPinjam.BackColor = Color.PowderBlue;
            btnPinjam.FlatAppearance.BorderColor = Color.Black;
            btnPinjam.FlatStyle = FlatStyle.Flat;
            btnPinjam.ForeColor = Color.Black;
            btnPinjam.Location = new Point(40, 287);
            btnPinjam.Name = "btnPinjam";
            btnPinjam.Size = new Size(73, 29);
            btnPinjam.TabIndex = 10;
            btnPinjam.Text = "Pinjam";
            btnPinjam.UseVisualStyleBackColor = false;
            btnPinjam.Click += btnPinjam_Click;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Location = new Point(322, 41);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(35, 20);
            lblCari.TabIndex = 9;
            lblCari.Text = "Cari";
            lblCari.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // dtpPengembalian
            // 
            dtpPengembalian.Location = new Point(40, 247);
            dtpPengembalian.Margin = new Padding(3, 5, 3, 10);
            dtpPengembalian.MinDate = new DateTime(2026, 2, 20, 0, 0, 0, 0);
            dtpPengembalian.Name = "dtpPengembalian";
            dtpPengembalian.Size = new Size(254, 27);
            dtpPengembalian.TabIndex = 8;
            // 
            // lblTanggalKembali
            // 
            lblTanggalKembali.AutoSize = true;
            lblTanggalKembali.Location = new Point(40, 222);
            lblTanggalKembali.Name = "lblTanggalKembali";
            lblTanggalKembali.Size = new Size(120, 20);
            lblTanggalKembali.TabIndex = 7;
            lblTanggalKembali.Text = "Tanggal Kembali";
            // 
            // txtNomBuk
            // 
            txtNomBuk.Location = new Point(40, 123);
            txtNomBuk.Margin = new Padding(3, 5, 3, 10);
            txtNomBuk.Name = "txtNomBuk";
            txtNomBuk.Size = new Size(254, 27);
            txtNomBuk.TabIndex = 6;
            txtNomBuk.TextChanged += txtNomBuk_TextChanged;
            // 
            // txtNIS
            // 
            txtNIS.Location = new Point(40, 61);
            txtNIS.Margin = new Padding(3, 5, 3, 10);
            txtNIS.Name = "txtNIS";
            txtNIS.ReadOnly = true;
            txtNIS.Size = new Size(254, 27);
            txtNIS.TabIndex = 5;
            // 
            // dtpPinjam
            // 
            dtpPinjam.Location = new Point(40, 185);
            dtpPinjam.Margin = new Padding(3, 5, 3, 10);
            dtpPinjam.MinDate = new DateTime(2026, 2, 20, 0, 0, 0, 0);
            dtpPinjam.Name = "dtpPinjam";
            dtpPinjam.RightToLeft = RightToLeft.No;
            dtpPinjam.Size = new Size(254, 27);
            dtpPinjam.TabIndex = 4;
            dtpPinjam.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // lblTangganPinjam
            // 
            lblTangganPinjam.AutoSize = true;
            lblTangganPinjam.Location = new Point(40, 160);
            lblTangganPinjam.Name = "lblTangganPinjam";
            lblTangganPinjam.Size = new Size(110, 20);
            lblTangganPinjam.TabIndex = 3;
            lblTangganPinjam.Text = "Tanggal Pinjam";
            lblTangganPinjam.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblNomorBuku
            // 
            lblNomorBuku.AutoSize = true;
            lblNomorBuku.Location = new Point(40, 98);
            lblNomorBuku.Name = "lblNomorBuku";
            lblNomorBuku.Size = new Size(92, 20);
            lblNomorBuku.TabIndex = 2;
            lblNomorBuku.Text = "Nomor Buku";
            // 
            // lblNis
            // 
            lblNis.AutoSize = true;
            lblNis.Location = new Point(40, 38);
            lblNis.Name = "lblNis";
            lblNis.Size = new Size(32, 20);
            lblNis.TabIndex = 1;
            lblNis.Text = "NIS";
            lblNis.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // dgvBuku
            // 
            dgvBuku.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBuku.Location = new Point(322, 68);
            dgvBuku.Name = "dgvBuku";
            dgvBuku.RowHeadersWidth = 51;
            dgvBuku.Size = new Size(385, 244);
            dgvBuku.TabIndex = 0;
            dgvBuku.SelectionChanged += dgvBuku_SelectionChanged;
            // 
            // FrmPeminjaman
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(732, 422);
            Controls.Add(pnlContent);
            Controls.Add(pnlHeader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmPeminjaman";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Peminjaman";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            pnlContent.ResumeLayout(false);
            pnlContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Panel pnlContent;
        private Label lblJudul;
        private PictureBox picLogo;
        private Button btnkembali;
        private TextBox txtNomBuk;
        private TextBox txtNIS;
        private DateTimePicker dtpPinjam;
        private Label lblTangganPinjam;
        private Label lblNomorBuku;
        private Label lblNis;
        private DataGridView dgvBuku;
        private DateTimePicker dtpPengembalian;
        private Label lblTanggalKembali;
        private TextBox txtCari;
        private Button btnBack;
        private Button btnPinjam;
        private Label lblCari;
        private Button btnRefresh;
        private Button btnCari;
    }
}