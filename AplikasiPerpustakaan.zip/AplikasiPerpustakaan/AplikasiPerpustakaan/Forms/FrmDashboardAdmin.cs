﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmDashboardAdmin : Form
    {
        public FrmDashboardAdmin()
        {
            InitializeComponent();
            LoadRingkasan();
            LoadDaftarBuku();
        }

        private void LoadRingkasan()
        {
            try
            {
                //Tersedia
                object tersedia = DatabaseHelper.ExecuteScalar("select count(*) from buku where status = 'Tersedia'");
                lblBukuTersedia.Text = tersedia?.ToString() ?? "0";

                //Anggota
                object anggota = DatabaseHelper.ExecuteScalar("select count(*) from anggota");
                lblAnggota.Text = anggota?.ToString() ?? "0";

                //Dipinjam
                object dipinjam = DatabaseHelper.ExecuteScalar("select count(*) from buku where status = 'Dipinjam'");
                lblDipinjam.Text = dipinjam?.ToString() ?? "0";

                //Jumlah Buku
                object jumlah = DatabaseHelper.ExecuteScalar("Select count(*) from buku");
                lblJumlah.Text = jumlah?.ToString() ?? "0";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tidak bisa memuat data: \n" + ex.Message, "Error Database");
            }
        }

        private void LoadDaftarBuku(string cari = "")
        {
            string query = @"
                SELECT
                    nomor_buku as 'No Buku',
                    judul as 'Judul',
                    pengarang as 'Pengarang',
                    genre as 'Genre',
                    status as 'Status'
                FROM buku";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " WHERE judul like @cari or pengarang like @cari or genre like @cari";
            }
            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvTabel.DataSource = dt;

                if (dgvTabel.Columns.Count > 0)
                {
                    dgvTabel.Columns["No Buku"].Width = 80;
                    dgvTabel.Columns["Judul"].Width = 250;
                    dgvTabel.Columns["Pengarang"].Width = 200;
                    dgvTabel.Columns["Genre"].Width = 120;
                    dgvTabel.Columns["Status"].Width = 100;
                }

                foreach (DataGridViewRow row in dgvTabel.Rows)
                {
                    string status = row.Cells["Status"].Value?.ToString()?.Trim();

                    if (status == "Tersedia")
                    {
                        row.DefaultCellStyle.BackColor = Color.LightGreen;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else if (status == "Dipinjam")
                    {
                        row.DefaultCellStyle.BackColor = Color.Orange;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                }
            }
            catch
            { 
            }
        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            txtCari.Focus();
            LoadDaftarBuku();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pnlTersedia_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            new FrmLogin().Show();
        }

        private void btnKelolaBuku_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (FrmKelolaBuku frm = new FrmKelolaBuku())
            {
                frm.ShowDialog();
            }
            this.Show();

            LoadRingkasan();
            LoadDaftarBuku();
        }

        private void btnKelolaAnggota_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (FrmAnggota frm = new FrmAnggota())
            {
                frm.ShowDialog();
            }

            this.Show();
            LoadRingkasan();
        }

        private void btnPeminjaman_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (FrmDaftarPeminjaman frm = new FrmDaftarPeminjaman())
            {
                frm.ShowDialog();
            }

            this.Show();
            LoadDaftarBuku();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            txtCari.Focus();
            LoadDaftarBuku();
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string cari = txtCari.Text.Trim();
            LoadDaftarBuku(cari); 
        }
    }
}
