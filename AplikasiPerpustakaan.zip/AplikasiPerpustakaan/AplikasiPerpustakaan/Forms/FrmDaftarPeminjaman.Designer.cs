﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmDaftarPeminjaman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDaftarPeminjaman));
            pnlHeader = new Panel();
            btnBack = new Button();
            pictureBox1 = new PictureBox();
            lblJudul = new Label();
            dgvPeminjaman = new DataGridView();
            txtCari = new TextBox();
            button2 = new Button();
            btnCari = new Button();
            lblCari = new Label();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPeminjaman).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnBack);
            pnlHeader.Controls.Add(pictureBox1);
            pnlHeader.Controls.Add(lblJudul);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 80);
            pnlHeader.TabIndex = 2;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.DeepSkyBlue;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = SystemColors.Control;
            btnBack.Location = new Point(680, 28);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 30);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // lblJudul
            // 
            lblJudul.AutoSize = true;
            lblJudul.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudul.ForeColor = Color.White;
            lblJudul.Location = new Point(96, 20);
            lblJudul.Name = "lblJudul";
            lblJudul.Size = new Size(273, 38);
            lblJudul.TabIndex = 1;
            lblJudul.Text = "Daftar Peminjaman";
            // 
            // dgvPeminjaman
            // 
            dgvPeminjaman.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPeminjaman.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPeminjaman.Location = new Point(33, 126);
            dgvPeminjaman.Name = "dgvPeminjaman";
            dgvPeminjaman.ReadOnly = true;
            dgvPeminjaman.RowHeadersWidth = 51;
            dgvPeminjaman.Size = new Size(741, 273);
            dgvPeminjaman.TabIndex = 34;
            // 
            // txtCari
            // 
            txtCari.Location = new Point(78, 93);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(563, 27);
            txtCari.TabIndex = 39;
            // 
            // button2
            // 
            button2.Location = new Point(708, 91);
            button2.Name = "button2";
            button2.Size = new Size(66, 29);
            button2.TabIndex = 41;
            button2.Text = "Refresh";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(647, 91);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(55, 29);
            btnCari.TabIndex = 40;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(32, 94);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(40, 23);
            lblCari.TabIndex = 38;
            lblCari.Text = "Cari";
            lblCari.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // FrmDaftarPeminjaman
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtCari);
            Controls.Add(button2);
            Controls.Add(btnCari);
            Controls.Add(lblCari);
            Controls.Add(dgvPeminjaman);
            Controls.Add(pnlHeader);
            Name = "FrmDaftarPeminjaman";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Daftar Peminjaman";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPeminjaman).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlHeader;
        private Button btnBack;
        private PictureBox pictureBox1;
        private Label lblJudul;
        private DataGridView dgvPeminjaman;
        private TextBox txtCari;
        private Button button2;
        private Button btnCari;
        private Label lblCari;
    }
}