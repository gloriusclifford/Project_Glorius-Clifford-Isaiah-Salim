﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmKelolaBuku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmKelolaBuku));
            pnlHeader = new Panel();
            btnBack = new Button();
            pictureBox1 = new PictureBox();
            lblPengembalian = new Label();
            pnlContent = new Panel();
            pnlInput = new Panel();
            txtNomorBuku = new TextBox();
            lblNomorBuku = new Label();
            btnTambah = new Button();
            txtPengarang = new TextBox();
            txtJudulBuku = new TextBox();
            lblGenre = new Label();
            btnHapus = new Button();
            lblPengarang = new Label();
            lblJudulBuku = new Label();
            txtGenre = new TextBox();
            btnUpdate = new Button();
            txtCari = new TextBox();
            btnRefresh = new Button();
            btnCari = new Button();
            dgvKelolaBuku = new DataGridView();
            lblCari = new Label();
            lblStatus = new Label();
            txtStatus = new TextBox();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlContent.SuspendLayout();
            pnlInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKelolaBuku).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnBack);
            pnlHeader.Controls.Add(pictureBox1);
            pnlHeader.Controls.Add(lblPengembalian);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 80);
            pnlHeader.TabIndex = 1;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.DeepSkyBlue;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = SystemColors.Control;
            btnBack.Location = new Point(679, 28);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 30);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // lblPengembalian
            // 
            lblPengembalian.AutoSize = true;
            lblPengembalian.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPengembalian.ForeColor = Color.White;
            lblPengembalian.Location = new Point(96, 20);
            lblPengembalian.Name = "lblPengembalian";
            lblPengembalian.Size = new Size(174, 38);
            lblPengembalian.TabIndex = 1;
            lblPengembalian.Text = "Kelola Buku";
            // 
            // pnlContent
            // 
            pnlContent.Controls.Add(pnlInput);
            pnlContent.Controls.Add(txtCari);
            pnlContent.Controls.Add(btnRefresh);
            pnlContent.Controls.Add(btnCari);
            pnlContent.Controls.Add(dgvKelolaBuku);
            pnlContent.Controls.Add(lblCari);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(0, 80);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(800, 370);
            pnlContent.TabIndex = 2;
            // 
            // pnlInput
            // 
            pnlInput.BackColor = Color.PowderBlue;
            pnlInput.Controls.Add(txtStatus);
            pnlInput.Controls.Add(lblStatus);
            pnlInput.Controls.Add(txtNomorBuku);
            pnlInput.Controls.Add(lblNomorBuku);
            pnlInput.Controls.Add(btnTambah);
            pnlInput.Controls.Add(txtPengarang);
            pnlInput.Controls.Add(txtJudulBuku);
            pnlInput.Controls.Add(lblGenre);
            pnlInput.Controls.Add(btnHapus);
            pnlInput.Controls.Add(lblPengarang);
            pnlInput.Controls.Add(lblJudulBuku);
            pnlInput.Controls.Add(txtGenre);
            pnlInput.Controls.Add(btnUpdate);
            pnlInput.Location = new Point(32, 214);
            pnlInput.Name = "pnlInput";
            pnlInput.Size = new Size(741, 144);
            pnlInput.TabIndex = 38;
            // 
            // txtNomorBuku
            // 
            txtNomorBuku.Location = new Point(18, 40);
            txtNomorBuku.Name = "txtNomorBuku";
            txtNomorBuku.Size = new Size(130, 27);
            txtNomorBuku.TabIndex = 38;
            // 
            // lblNomorBuku
            // 
            lblNomorBuku.AutoSize = true;
            lblNomorBuku.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNomorBuku.Location = new Point(18, 17);
            lblNomorBuku.Name = "lblNomorBuku";
            lblNomorBuku.Size = new Size(97, 20);
            lblNomorBuku.TabIndex = 37;
            lblNomorBuku.Text = "Nomor Buku";
            lblNomorBuku.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnTambah
            // 
            btnTambah.BackColor = Color.Transparent;
            btnTambah.FlatAppearance.BorderSize = 0;
            btnTambah.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTambah.ForeColor = Color.Black;
            btnTambah.Location = new Point(18, 93);
            btnTambah.Name = "btnTambah";
            btnTambah.Size = new Size(80, 29);
            btnTambah.TabIndex = 36;
            btnTambah.Text = "Tambah";
            btnTambah.UseVisualStyleBackColor = false;
            btnTambah.Click += btnTambah_Click;
            // 
            // txtPengarang
            // 
            txtPengarang.Location = new Point(290, 40);
            txtPengarang.Name = "txtPengarang";
            txtPengarang.Size = new Size(130, 27);
            txtPengarang.TabIndex = 33;
            // 
            // txtJudulBuku
            // 
            txtJudulBuku.Location = new Point(154, 40);
            txtJudulBuku.Name = "txtJudulBuku";
            txtJudulBuku.Size = new Size(130, 27);
            txtJudulBuku.TabIndex = 32;
            // 
            // lblGenre
            // 
            lblGenre.AutoSize = true;
            lblGenre.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblGenre.Location = new Point(426, 17);
            lblGenre.Name = "lblGenre";
            lblGenre.Size = new Size(50, 20);
            lblGenre.TabIndex = 23;
            lblGenre.Text = "Genre";
            lblGenre.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnHapus
            // 
            btnHapus.BackColor = Color.Transparent;
            btnHapus.FlatAppearance.BorderSize = 0;
            btnHapus.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHapus.ForeColor = Color.Black;
            btnHapus.Location = new Point(190, 93);
            btnHapus.Name = "btnHapus";
            btnHapus.Size = new Size(80, 29);
            btnHapus.TabIndex = 31;
            btnHapus.Text = "Hapus";
            btnHapus.UseVisualStyleBackColor = false;
            btnHapus.Click += btnHapus_Click;
            // 
            // lblPengarang
            // 
            lblPengarang.AutoSize = true;
            lblPengarang.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblPengarang.Location = new Point(290, 17);
            lblPengarang.Name = "lblPengarang";
            lblPengarang.Size = new Size(83, 20);
            lblPengarang.TabIndex = 21;
            lblPengarang.Text = "Pengarang";
            lblPengarang.TextAlign = ContentAlignment.MiddleLeft;
            lblPengarang.Click += lblPengarang_Click;
            // 
            // lblJudulBuku
            // 
            lblJudulBuku.AutoSize = true;
            lblJudulBuku.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblJudulBuku.Location = new Point(154, 17);
            lblJudulBuku.Name = "lblJudulBuku";
            lblJudulBuku.Size = new Size(85, 20);
            lblJudulBuku.TabIndex = 19;
            lblJudulBuku.Text = "Judul Buku";
            lblJudulBuku.TextAlign = ContentAlignment.MiddleLeft;
            lblJudulBuku.Click += lblNIS_Click;
            // 
            // txtGenre
            // 
            txtGenre.Location = new Point(426, 40);
            txtGenre.Name = "txtGenre";
            txtGenre.Size = new Size(130, 27);
            txtGenre.TabIndex = 28;
            // 
            // btnUpdate
            // 
            btnUpdate.FlatStyle = FlatStyle.System;
            btnUpdate.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.Location = new Point(104, 93);
            btnUpdate.Margin = new Padding(3, 3, 3, 10);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(80, 29);
            btnUpdate.TabIndex = 29;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // txtCari
            // 
            txtCari.Location = new Point(77, 8);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(563, 27);
            txtCari.TabIndex = 35;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(707, 6);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(66, 29);
            btnRefresh.TabIndex = 37;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(646, 6);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(55, 29);
            btnCari.TabIndex = 36;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // dgvKelolaBuku
            // 
            dgvKelolaBuku.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvKelolaBuku.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvKelolaBuku.Location = new Point(32, 41);
            dgvKelolaBuku.Name = "dgvKelolaBuku";
            dgvKelolaBuku.ReadOnly = true;
            dgvKelolaBuku.RowHeadersWidth = 51;
            dgvKelolaBuku.Size = new Size(741, 158);
            dgvKelolaBuku.TabIndex = 33;
            dgvKelolaBuku.SelectionChanged += dgvKelolaBuku_SelectionChange;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(31, 9);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(40, 23);
            lblCari.TabIndex = 34;
            lblCari.Text = "Cari";
            lblCari.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            lblStatus.Location = new Point(562, 17);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 39;
            lblStatus.Text = "Status";
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(562, 40);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(130, 27);
            txtStatus.TabIndex = 40;
            // 
            // FrmKelolaBuku
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnlContent);
            Controls.Add(pnlHeader);
            Name = "FrmKelolaBuku";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Kelola Buku";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlContent.ResumeLayout(false);
            pnlContent.PerformLayout();
            pnlInput.ResumeLayout(false);
            pnlInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKelolaBuku).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Button btnBack;
        private PictureBox pictureBox1;
        private Label lblPengembalian;
        private Panel pnlContent;
        private Panel pnlInput;
        private TextBox txtPassword;
        private TextBox txtAlamat;
        private Label lblTelepon;
        private TextBox txtUsername;
        private Button btnHapus;
        private Label lblUsername;
        private TextBox txtNIS;
        private TextBox txtNama;
        private Label lblPengarang;
        private TextBox txtTelepon;
        private Label lblJudulBuku;
        private Label lblNama;
        private TextBox txtGenre;
        private Button btnUpdate;
        private TextBox txtCari;
        private Button btnRefresh;
        private Button btnCari;
        private DataGridView dgvKelolaBuku;
        private Label lblCari;
        private Label lblGenre;
        private TextBox txtPengarang;
        private TextBox txtJudulBuku;
        private Button btnTambah;
        private TextBox txtNomorBuku;
        private Label lblNomorBuku;
        private TextBox txtStatus;
        private Label lblStatus;
    }
}