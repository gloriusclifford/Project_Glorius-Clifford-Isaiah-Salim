﻿using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using BCrypt.Net;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmAnggota : Form
    {
        private string nisDipilih = "";
        public FrmAnggota()
        {
            InitializeComponent();
            LoadDaftarAnggota();
            ClearForm();
        }

        private void LoadDaftarAnggota(string cari = "")
        {
            string query = @"
                SELECT 
                    a.nis AS 'NIS',
                    a.nama AS 'Nama',
                    a.alamat AS 'Alamat',
                    a.telepon AS 'Telepon',
                    a.kelas AS 'Kelas',
                    u.username AS 'Username'
                FROM anggota a
                LEFT JOIN users u ON a.nis = u.nis";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " WHERE a.nis LIKE @cari OR a.nama LIKE @cari OR u.username LIKE @cari";
            }

            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvAnggota.DataSource = dt;

                if (dgvAnggota.Columns.Count > 0)
                {
                    dgvAnggota.Columns["NIS"].Width = 80;
                    dgvAnggota.Columns["Nama"].Width = 150;
                    dgvAnggota.Columns["Alamat"].Width = 180;
                    dgvAnggota.Columns["Telepon"].Width = 100;
                    dgvAnggota.Columns["Kelas"].Width = 80;
                    dgvAnggota.Columns["Username"].Width = 120;
                }
            }
            catch
            { }
        }

        private void pnlContent_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            txtCari.Text.Trim();
            LoadDaftarAnggota();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadDaftarAnggota();
        }

        private void dgvAnggota_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvAnggota.SelectedRows.Count > 0)
            {
                var row = dgvAnggota.SelectedRows[0];
                nisDipilih = row.Cells["NIS"].Value.ToString();

                txtNIS.Text = nisDipilih;
                txtNama.Text = row.Cells["Nama"].Value.ToString();
                txtAlamat.Text = row.Cells["Alamat"].Value.ToString();
                txtTelepon.Text = row.Cells["Telepon"].Value.ToString();
                txtKelas.Text = row.Cells["Kelas"].Value.ToString();
                txtUsername.Text = row.Cells["Username"].Value?.ToString() ?? "";

                txtNIS.ReadOnly = true;  // NIS tidak boleh diubah
                btnUpdate.Enabled = true;
                btnHapus.Enabled = true;
            }
            else
            {
                ClearForm();
            }
        }
        private void ClearForm()
        {
            nisDipilih = "";
            txtNIS.Clear();
            txtNama.Clear();
            txtAlamat.Clear();
            txtTelepon.Clear();
            txtKelas.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            txtNIS.ReadOnly = false;
            btnUpdate.Enabled = false;
            btnHapus.Enabled = false;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nisDipilih))
            {
                MessageBox.Show("Pilih anggota terlebih dahulu!", "Peringatan");
                return;
            }

            if (string.IsNullOrEmpty(txtNama.Text) || string.IsNullOrEmpty(txtAlamat.Text) ||
                string.IsNullOrEmpty(txtTelepon.Text) || string.IsNullOrEmpty(txtKelas.Text) ||
                string.IsNullOrEmpty(txtUsername.Text))
            {
                MessageBox.Show("Semua field wajib diisi kecuali password!", "Peringatan");
                return;
            }

            try
            {
                string qAnggota = @"
                    UPDATE anggota 
                    SET nama = @nama, alamat = @alamat, telepon = @telepon, kelas = @kelas 
                    WHERE nis = @nis";

                DatabaseHelper.ExecuteNonQuery(qAnggota,
                    new MySqlParameter("@nama", txtNama.Text.Trim()),
                    new MySqlParameter("@alamat", txtAlamat.Text.Trim()),
                    new MySqlParameter("@telepon", txtTelepon.Text.Trim()),
                    new MySqlParameter("@kelas", txtKelas.Text.Trim()),
                    new MySqlParameter("@nis", nisDipilih));

                string qUser = "UPDATE users SET username = @username";
                var paramsUser = new List<MySqlParameter> { new MySqlParameter("@username", txtUsername.Text.Trim()) };

                if (!string.IsNullOrEmpty(txtPassword.Text))
                {
                    string hashed = BCrypt.Net.BCrypt.HashPassword(txtPassword.Text.Trim());
                    qUser += ", password = @password";
                    paramsUser.Add(new MySqlParameter("@password", hashed));
                }

                qUser += " WHERE nis = @nis";
                paramsUser.Add(new MySqlParameter("@nis", nisDipilih));

                DatabaseHelper.ExecuteNonQuery(qUser, paramsUser.ToArray());

                MessageBox.Show("Data anggota berhasil diupdate!", "Sukses");
                LoadDaftarAnggota();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal update data:\n" + ex.Message, "Error");
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nisDipilih))
            {
                MessageBox.Show("Pilih anggota terlebih dahulu!", "Peringatan");
                return;
            }

            if (MessageBox.Show("Yakin ingin menghapus anggota ini?\nSemua data terkait (peminjaman, login) juga akan hilang!", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;

            try
            {
                // Hapus users dulu (karena FK)
                DatabaseHelper.ExecuteNonQuery("DELETE FROM users WHERE nis = @nis", new MySqlParameter("@nis", nisDipilih));

                // Hapus anggota
                DatabaseHelper.ExecuteNonQuery("DELETE FROM anggota WHERE nis = @nis", new MySqlParameter("@nis", nisDipilih));

                MessageBox.Show("Anggota berhasil dihapus!", "Sukses");
                LoadDaftarAnggota();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menghapus:\n" + ex.Message, "Error");
            }
        }
    }

}

