﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmAnggota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAnggota));
            pnlHeader = new Panel();
            btnBack = new Button();
            pictureBox1 = new PictureBox();
            lblPengembalian = new Label();
            pnlContent = new Panel();
            pnlInput = new Panel();
            lblKelas = new Label();
            txtPassword = new TextBox();
            txtAlamat = new TextBox();
            lblPassword = new Label();
            lblTelepon = new Label();
            txtUsername = new TextBox();
            btnHapus = new Button();
            lblUsername = new Label();
            txtNIS = new TextBox();
            txtNama = new TextBox();
            lblAlamat = new Label();
            txtTelepon = new TextBox();
            lblNIS = new Label();
            lblNama = new Label();
            txtKelas = new TextBox();
            btnUpdate = new Button();
            txtCari = new TextBox();
            btnCari = new Button();
            lblCari = new Label();
            dgvAnggota = new DataGridView();
            button2 = new Button();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlContent.SuspendLayout();
            pnlInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAnggota).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnBack);
            pnlHeader.Controls.Add(pictureBox1);
            pnlHeader.Controls.Add(lblPengembalian);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 80);
            pnlHeader.TabIndex = 1;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.DeepSkyBlue;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = SystemColors.Control;
            btnBack.Location = new Point(680, 28);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 30);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // lblPengembalian
            // 
            lblPengembalian.AutoSize = true;
            lblPengembalian.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPengembalian.ForeColor = Color.White;
            lblPengembalian.Location = new Point(96, 20);
            lblPengembalian.Name = "lblPengembalian";
            lblPengembalian.Size = new Size(220, 38);
            lblPengembalian.TabIndex = 1;
            lblPengembalian.Text = "Kelola Anggota";
            // 
            // pnlContent
            // 
            pnlContent.Controls.Add(pnlInput);
            pnlContent.Controls.Add(txtCari);
            pnlContent.Controls.Add(btnCari);
            pnlContent.Controls.Add(lblCari);
            pnlContent.Controls.Add(dgvAnggota);
            pnlContent.Controls.Add(button2);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(0, 80);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(800, 370);
            pnlContent.TabIndex = 2;
            // 
            // pnlInput
            // 
            pnlInput.BackColor = Color.PowderBlue;
            pnlInput.Controls.Add(lblKelas);
            pnlInput.Controls.Add(txtPassword);
            pnlInput.Controls.Add(txtAlamat);
            pnlInput.Controls.Add(lblPassword);
            pnlInput.Controls.Add(lblTelepon);
            pnlInput.Controls.Add(txtUsername);
            pnlInput.Controls.Add(btnHapus);
            pnlInput.Controls.Add(lblUsername);
            pnlInput.Controls.Add(txtNIS);
            pnlInput.Controls.Add(txtNama);
            pnlInput.Controls.Add(lblAlamat);
            pnlInput.Controls.Add(txtTelepon);
            pnlInput.Controls.Add(lblNIS);
            pnlInput.Controls.Add(lblNama);
            pnlInput.Controls.Add(txtKelas);
            pnlInput.Controls.Add(btnUpdate);
            pnlInput.Location = new Point(33, 22);
            pnlInput.Name = "pnlInput";
            pnlInput.Size = new Size(301, 310);
            pnlInput.TabIndex = 32;
            // 
            // lblKelas
            // 
            lblKelas.AutoSize = true;
            lblKelas.Location = new Point(17, 137);
            lblKelas.Name = "lblKelas";
            lblKelas.Size = new Size(44, 20);
            lblKelas.TabIndex = 23;
            lblKelas.Text = "Kelas";
            lblKelas.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(17, 213);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(130, 27);
            txtPassword.TabIndex = 36;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // txtAlamat
            // 
            txtAlamat.Location = new Point(17, 107);
            txtAlamat.Name = "txtAlamat";
            txtAlamat.Size = new Size(130, 27);
            txtAlamat.TabIndex = 26;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(17, 190);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(70, 20);
            lblPassword.TabIndex = 35;
            lblPassword.Text = "Password";
            lblPassword.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblTelepon
            // 
            lblTelepon.AutoSize = true;
            lblTelepon.Location = new Point(153, 84);
            lblTelepon.Name = "lblTelepon";
            lblTelepon.Size = new Size(62, 20);
            lblTelepon.TabIndex = 22;
            lblTelepon.Text = "Telepon";
            lblTelepon.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(153, 160);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(130, 27);
            txtUsername.TabIndex = 34;
            // 
            // btnHapus
            // 
            btnHapus.BackColor = Color.Transparent;
            btnHapus.FlatAppearance.BorderSize = 0;
            btnHapus.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHapus.ForeColor = Color.Black;
            btnHapus.Location = new Point(103, 268);
            btnHapus.Name = "btnHapus";
            btnHapus.Size = new Size(80, 29);
            btnHapus.TabIndex = 31;
            btnHapus.Text = "Hapus";
            btnHapus.UseVisualStyleBackColor = false;
            btnHapus.Click += btnHapus_Click;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(153, 137);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(75, 20);
            lblUsername.TabIndex = 33;
            lblUsername.Text = "Username";
            lblUsername.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtNIS
            // 
            txtNIS.Location = new Point(17, 54);
            txtNIS.Name = "txtNIS";
            txtNIS.Size = new Size(130, 27);
            txtNIS.TabIndex = 24;
            // 
            // txtNama
            // 
            txtNama.Location = new Point(153, 54);
            txtNama.Name = "txtNama";
            txtNama.Size = new Size(130, 27);
            txtNama.TabIndex = 25;
            // 
            // lblAlamat
            // 
            lblAlamat.AutoSize = true;
            lblAlamat.Location = new Point(17, 84);
            lblAlamat.Name = "lblAlamat";
            lblAlamat.Size = new Size(57, 20);
            lblAlamat.TabIndex = 21;
            lblAlamat.Text = "Alamat";
            lblAlamat.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtTelepon
            // 
            txtTelepon.Location = new Point(153, 107);
            txtTelepon.Name = "txtTelepon";
            txtTelepon.Size = new Size(130, 27);
            txtTelepon.TabIndex = 27;
            // 
            // lblNIS
            // 
            lblNIS.AutoSize = true;
            lblNIS.Location = new Point(17, 28);
            lblNIS.Name = "lblNIS";
            lblNIS.Size = new Size(32, 20);
            lblNIS.TabIndex = 19;
            lblNIS.Text = "NIS";
            lblNIS.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblNama
            // 
            lblNama.AutoSize = true;
            lblNama.Location = new Point(153, 30);
            lblNama.Name = "lblNama";
            lblNama.Size = new Size(53, 20);
            lblNama.TabIndex = 20;
            lblNama.Text = "NAMA";
            lblNama.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtKelas
            // 
            txtKelas.Location = new Point(17, 160);
            txtKelas.Name = "txtKelas";
            txtKelas.Size = new Size(130, 27);
            txtKelas.TabIndex = 28;
            // 
            // btnUpdate
            // 
            btnUpdate.FlatStyle = FlatStyle.System;
            btnUpdate.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.Location = new Point(17, 268);
            btnUpdate.Margin = new Padding(10, 3, 3, 10);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(80, 29);
            btnUpdate.TabIndex = 29;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // txtCari
            // 
            txtCari.Location = new Point(413, 52);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(228, 27);
            txtCari.TabIndex = 16;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(647, 53);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(55, 29);
            btnCari.TabIndex = 17;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(367, 53);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(40, 23);
            lblCari.TabIndex = 15;
            lblCari.Text = "Cari";
            lblCari.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // dgvAnggota
            // 
            dgvAnggota.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAnggota.Location = new Point(365, 83);
            dgvAnggota.Name = "dgvAnggota";
            dgvAnggota.ReadOnly = true;
            dgvAnggota.RowHeadersWidth = 51;
            dgvAnggota.Size = new Size(409, 222);
            dgvAnggota.TabIndex = 1;
            dgvAnggota.SelectionChanged += dgvAnggota_SelectionChanged;
            // 
            // button2
            // 
            button2.Location = new Point(708, 53);
            button2.Name = "button2";
            button2.Size = new Size(66, 29);
            button2.TabIndex = 18;
            button2.Text = "Refresh";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // FrmAnggota
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnlContent);
            Controls.Add(pnlHeader);
            Name = "FrmAnggota";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Kelola Anggota";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlContent.ResumeLayout(false);
            pnlContent.PerformLayout();
            pnlInput.ResumeLayout(false);
            pnlInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvAnggota).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Button btnBack;
        private PictureBox pictureBox1;
        private Label lblPengembalian;
        private Panel pnlContent;
        private Button button2;
        private Button btnCari;
        private TextBox txtCari;
        private Label lblCari;
        private DataGridView dgvAnggota;
        private TextBox txtKelas;
        private TextBox txtTelepon;
        private TextBox txtAlamat;
        private TextBox txtNama;
        private TextBox txtNIS;
        private Label lblKelas;
        private Label lblTelepon;
        private Label lblAlamat;
        private Label lblNama;
        private Label lblNIS;
        private Panel pnlInput;
        private Button btnHapus;
        private Button btnUpdate;
        private TextBox txtPassword;
        private Label lblPassword;
        private TextBox txtUsername;
        private Label lblUsername;
    }
}