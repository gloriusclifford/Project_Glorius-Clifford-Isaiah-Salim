﻿using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmPengembalian : Form
    {
        private string nisUser;

        public FrmPengembalian(string nis)
        {
            InitializeComponent();
            nisUser = nis;
            lblWelcome.Text = "Selamat Datang, " + GetNamaUser(nis);
            LoadPeminjamanSaya();
        }


        private string GetNamaUser(string nis)
        {
            string query = "Select nama from anggota where nis = @nis";
            object nama = DatabaseHelper.ExecuteScalar(query, new MySqlParameter("@nis", nis));
            return nama?.ToString() ?? "Anggota";
        }

        private void LoadPeminjamanSaya(string cari = "")
        {
            string query = @"
                SELECT 
                    p.id_peminjaman AS 'ID',
                    p.nomor_buku AS 'No Buku',
                    b.judul AS 'Judul Buku',
                    p.tgl_pinjam AS 'Tgl Pinjam',
                    p.tgl_kembali AS 'Tgl Kembali'
                FROM peminjaman p
                JOIN buku b ON p.nomor_buku = b.nomor_buku
                WHERE p.nis = @nisUser";

            if (!string.IsNullOrEmpty(cari))
            {
                query += "and b.judul like @cari";
            }
            
            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@nisUser", nisUser),
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvPeminjamanSaya.DataSource = dt;

                if (dgvPeminjamanSaya.Columns.Count > 0)
                {
                    dgvPeminjamanSaya.Columns["ID"].Width = 60;
                    dgvPeminjamanSaya.Columns["No Buku"].Width = 80;
                    dgvPeminjamanSaya.Columns["Judul Buku"].Width = 250;
                    dgvPeminjamanSaya.Columns["Tgl Pinjam"].Width = 120;
                    dgvPeminjamanSaya.Columns["Tgl Kembali"].Width = 140;
                }
            }
            catch
            {}
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string cari = txtCari.Text.Trim();
            LoadPeminjamanSaya(cari);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadPeminjamanSaya();
        }

        private void btnKembalikan_Click(object sender, EventArgs e)
        {
            if (dgvPeminjamanSaya.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih salah satu buku yang sedang dipinjam!");
                return;
            }
            DataGridViewRow row = dgvPeminjamanSaya.SelectedRows[0];
            string idPeminjaman = row.Cells["ID"].Value.ToString();
            string nomorBuku = row.Cells["No Buku"].Value.ToString();
            if (MessageBox.Show("Yakin ingin mengembalikan buku ini?", "Konfirmasi Pengembalian", MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            try
            {
                string qDelete = "DELETE FROM peminjaman WHERE id_peminjaman = @id";
                DatabaseHelper.ExecuteNonQuery(qDelete, new MySqlParameter("@id", idPeminjaman));

                string qUpdate = "UPDATE buku SET status = 'Tersedia' WHERE nomor_buku = @nomor";
                DatabaseHelper.ExecuteNonQuery(qUpdate, new MySqlParameter("@nomor", nomorBuku));

                MessageBox.Show("Buku berhasil dikembalikan! Status buku kembali Tersedia.", "Sukses");
                LoadPeminjamanSaya();
            }
            catch {}

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
