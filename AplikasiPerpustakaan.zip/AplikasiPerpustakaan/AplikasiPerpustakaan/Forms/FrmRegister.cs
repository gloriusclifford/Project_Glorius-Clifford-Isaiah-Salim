﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BCrypt.Net;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmRegister : Form
    {
        public FrmRegister()
        {
            InitializeComponent();
        }
        private void btnDaftar_Click(object sender, EventArgs e)
        {
            string nis = txtNIS.Text.Trim();
            string nama = txtNama.Text.Trim();
            string alamat = txtAlamat.Text.Trim();
            string teleponstr = txtTelepon.Text.Trim();
            string kelas = txtKelas.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            int telepon;

            if (string.IsNullOrEmpty(nis)
               || string.IsNullOrEmpty(nama)
               || string.IsNullOrEmpty(alamat)
               || string.IsNullOrEmpty(teleponstr)
               || string.IsNullOrEmpty(kelas)
               || string.IsNullOrEmpty(username)
               || string.IsNullOrEmpty(password))
            {
                lblError.Text = "Semua data harus diisi semua!!";
                lblError.Visible = true;
                txtNIS.Focus();
                return;
            }

            if (!int.TryParse(teleponstr, out telepon))
            {
                MessageBox.Show("Nomor Telepon Harus Berupa Angka Saja!!", "Ulangi!");
                txtTelepon.Focus();
                return;
            }


            string connstr = "Server=localhost;Database=perpustakaan_db;Uid=root;Pwd=;";
            string queryAnggota = "insert into anggota (nis,nama,alamat,telepon, kelas) values (@nis,@nama,@alamat,@telepon,@kelas)";
            string queryUsers = "insert into users (username,password,nis) values (@username,@password,@nis)";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connstr))
                {
                    conn.Open();
                    using (MySqlCommand cmdAnggota = new MySqlCommand(queryAnggota, conn))
                    {
                        cmdAnggota.Parameters.AddWithValue("@nis", nis);
                        cmdAnggota.Parameters.AddWithValue("@nama", nama);
                        cmdAnggota.Parameters.AddWithValue("@alamat", alamat);
                        cmdAnggota.Parameters.AddWithValue("@telepon", telepon);
                        cmdAnggota.Parameters.AddWithValue("@kelas", kelas);
                        cmdAnggota.ExecuteNonQuery();
                    }

                    string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

                    using (MySqlCommand cmdUsers = new MySqlCommand(queryUsers, conn))
                    {
                        cmdUsers.Parameters.AddWithValue("@username", username);
                        cmdUsers.Parameters.AddWithValue("@password", hashedPassword);
                        cmdUsers.Parameters.AddWithValue("@nis", nis);
                        cmdUsers.ExecuteNonQuery();
                    }
                }

                lblError.Text = "Pendaftaran Anggota Selesai! Silahkan Login";
                lblError.ForeColor = Color.Green;
                lblError.Visible = true;

                txtNIS.Clear();
                txtNama.Clear();
                txtAlamat.Clear();
                txtTelepon.Clear();
                txtKelas.Clear();
                txtUsername.Clear();
                txtPassword.Clear();
                chkShowPassword.Checked = false;
                txtNIS.Focus();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                {
                    lblError.Text = "Username/NIS sudah terdaftar";
                }
                else
                {
                    lblError.Text = "Error Database" + ex.Message;
                }
                lblError.ForeColor = Color.Red;
                lblError.Visible = true;
            }
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtPassword.UseSystemPasswordChar = true;
            }

            txtPassword.Refresh();
            txtPassword.Focus();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
