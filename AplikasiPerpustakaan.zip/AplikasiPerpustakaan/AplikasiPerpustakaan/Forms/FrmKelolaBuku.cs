﻿using AplikasiPerpustakaan.DataAccess;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmKelolaBuku : Form
    {
        private string nomorBukuDipilih = "";

        public FrmKelolaBuku()
        {
            InitializeComponent();
            LoadDaftarBuku();
            ClearForm();

            btnUpdate.Enabled = false;
            btnHapus.Enabled = false;
        }

        private void LoadDaftarBuku(string cari = "")
        {
            string query = @"
                SELECT 
                    nomor_buku AS 'No Buku',
                    judul AS 'Judul Buku',
                    pengarang AS 'Pengarang',
                    genre AS 'Genre',
                    status AS 'Status'
                FROM buku";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " where nomor_buku like @cari or judul like @cari or pengarang like @cari or genre like @cari";
            }

            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvKelolaBuku.DataSource = dt;

                if (dgvKelolaBuku.Columns.Count > 5) ;
                {
                    dgvKelolaBuku.Columns["No Buku"].Width = 80;
                    dgvKelolaBuku.Columns["Judul Buku"].Width = 250;
                    dgvKelolaBuku.Columns["Pengarang"].Width = 150;
                    dgvKelolaBuku.Columns["Genre"].Width = 100;
                    dgvKelolaBuku.Columns["Status"].Width = 100;
                }

                foreach (DataGridViewRow row in dgvKelolaBuku.Rows)
                {
                    string status = row.Cells["Status"].Value?.ToString()?.Trim();

                    if (status == "Tersedia")
                    {
                        row.DefaultCellStyle.BackColor = Color.LightGreen;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else if (status == "Dipinjam")
                    {
                        row.DefaultCellStyle.BackColor = Color.Orange;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                }
            }
            catch
            {

            }
        }


        private void ClearForm()
        {
            nomorBukuDipilih = "";
            txtNomorBuku.Clear();
            txtJudulBuku.Clear();
            txtPengarang.Clear();
            txtGenre.Clear();
            txtStatus.Clear();
            txtNomorBuku.ReadOnly = false;
            btnUpdate.Enabled = false;
            btnHapus.Enabled = false;
        }

        private void lblNIS_Click(object sender, EventArgs e)
        {

        }

        private void lblPengarang_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvKelolaBuku_SelectionChange(object sender, EventArgs e)
        {
            if (dgvKelolaBuku.SelectedRows.Count > 0)
            {
                var row = dgvKelolaBuku.SelectedRows[0];
                nomorBukuDipilih = row.Cells["No Buku"].Value.ToString();

                txtNomorBuku.Text = nomorBukuDipilih;
                txtJudulBuku.Text = row.Cells["Judul Buku"].Value.ToString();
                txtPengarang.Text = row.Cells["Pengarang"].Value.ToString();
                txtGenre.Text = row.Cells["Genre"].Value.ToString();
                txtStatus.Text = row.Cells["Status"].Value.ToString();

                txtNomorBuku.ReadOnly = true; // No Buku tidak boleh diubah saat edit
                btnUpdate.Enabled = true;
                btnHapus.Enabled = true;
            }
            else
            {
                ClearForm();
            }
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            txtCari.Text.Trim();
            LoadDaftarBuku();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadDaftarBuku();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nomorBukuDipilih))
            {
                MessageBox.Show("Pilih buku terlebih dahulu!", "Peringatan");
                return;
            }

            if (string.IsNullOrEmpty(txtJudulBuku.Text) || string.IsNullOrEmpty(txtPengarang.Text) ||
                string.IsNullOrEmpty(txtGenre.Text) || string.IsNullOrEmpty(txtStatus.Text))
            {
                MessageBox.Show("Judul, Pengarang, Genre, dan Status harus diisi!", "Peringatan");
                return;
            }

            try
            {
                string qUpdate = @"
                    UPDATE buku 
                    SET judul = @judul, pengarang = @pengarang, genre = @genre, status = @status 
                    WHERE nomor_buku = @nomor";

                DatabaseHelper.ExecuteNonQuery(qUpdate,
                    new MySqlParameter("@judul", txtJudulBuku.Text.Trim()),
                    new MySqlParameter("@pengarang", txtPengarang.Text.Trim()),
                    new MySqlParameter("@genre", txtGenre.Text.Trim()),
                    new MySqlParameter("@status", txtStatus.Text.Trim()),
                    new MySqlParameter("@nomor", nomorBukuDipilih));

                MessageBox.Show("Data buku berhasil diupdate!", "Sukses");
                LoadDaftarBuku();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal update buku:\n" + ex.Message, "Error");
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nomorBukuDipilih))
            {
                MessageBox.Show("Pilih buku terlebih dahulu!", "Peringatan");
                return;
            }

            if (MessageBox.Show("Yakin ingin menghapus buku ini?\nSemua data peminjaman terkait juga akan hilang!", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;

            try
            {
                // Hapus peminjaman terkait dulu
                DatabaseHelper.ExecuteNonQuery("DELETE FROM peminjaman WHERE nomor_buku = @nomor", new MySqlParameter("@nomor", nomorBukuDipilih));

                // Hapus buku
                DatabaseHelper.ExecuteNonQuery("DELETE FROM buku WHERE nomor_buku = @nomor", new MySqlParameter("@nomor", nomorBukuDipilih));

                MessageBox.Show("Buku berhasil dihapus!", "Sukses");
                LoadDaftarBuku();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menghapus buku:\n" + ex.Message, "Error");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvKelolaBuku.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih buku terlebih dahulu!", "Peringatan");
                return;
            }

            txtJudulBuku.Focus();
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            string nomor = txtNomorBuku.Text.Trim();
            string judul = txtJudulBuku.Text.Trim();
            string pengarang = txtPengarang.Text.Trim();
            string genre = txtGenre.Text.Trim();
            txtStatus.ReadOnly = true;

            if (string.IsNullOrEmpty(nomor) || string.IsNullOrEmpty(judul) ||
                string.IsNullOrEmpty(pengarang) || string.IsNullOrEmpty(genre))
            {
                MessageBox.Show("Data tidak boleh kosong!!");
                txtNomorBuku.Focus();
                return;
            }

            string qCheck = "select count(*) from buku where nomor_buku = @cari";
            object countObj = DatabaseHelper.ExecuteScalar(qCheck, new MySqlParameter("@nomor", nomor));
            int count = Convert.ToInt32(countObj ?? 0);

            if (count > 0)
            {
                MessageBox.Show("Nomor buku sudah tersedia di database! Gunakan nomor buku yang berbeda", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                string qTambah = "insert into buku (nomor_buku, judul, pengarang, genre) values (@nomor,@judul,@pengarang,@genre)";

                int rows = DatabaseHelper.ExecuteNonQuery(qTambah,
                    new MySqlParameter("@nomor", nomor),
                    new MySqlParameter("@judul", judul),
                    new MySqlParameter("@pengarang", pengarang),
                    new MySqlParameter("@genre", genre));

                if (rows > 0)
                {
                    MessageBox.Show("Buku berhasil ditambahkan", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDaftarBuku();
                    ClearForm();
                    txtNomorBuku.Focus();
                }
                else
                {
                    MessageBox.Show("Gagal menambahkan buku!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saat menambahkan buku:\n" + ex.Message, "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
