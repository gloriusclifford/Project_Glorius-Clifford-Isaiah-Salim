﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using AplikasiPerpustakaan.DataAccess;

namespace AplikasiPerpustakaan.Forms
{
    public partial class FrmDashboardUser : Form
    {
        public FrmDashboardUser()
        {
            InitializeComponent();
            LoadDaftarBuku();
        }

        private void LoadDaftarBuku(string cari = "")
        {
            string query = @"
                SELECT
                    nomor_buku AS 'No Buku',
                    judul AS 'Judul',
                    pengarang AS 'Pengarang',
                    genre AS 'Genre',
                    status AS 'Status'
                FROM buku";

            if (!string.IsNullOrEmpty(cari))
            {
                query += " WHERE judul LIKE @cari OR pengarang LIKE @cari OR genre LIKE @cari";
            }
            try
            {
                DataTable dt = DatabaseHelper.GetData(query,
                    new MySqlParameter("@cari", "%" + cari + "%"));

                dgvBuku.DataSource = dt;

                if (dgvBuku.Columns.Count > 0)
                {
                    dgvBuku.Columns["No Buku"].Width = 80;
                    dgvBuku.Columns["Judul"].Width = 250;
                    dgvBuku.Columns["Pengarang"].Width = 200;
                    dgvBuku.Columns["Genre"].Width = 120;
                    dgvBuku.Columns["Status"].Width = 100;

                }
                foreach (DataGridViewRow row in dgvBuku.Rows)
                {
                    string status = row.Cells["Status"].Value?.ToString()?.Trim();

                    if (status == "Tersedia")
                    {
                        row.DefaultCellStyle.BackColor = Color.LightGreen;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                    else if (status == "Dipinjam")
                    {
                        row.DefaultCellStyle.BackColor = Color.Orange;
                        row.DefaultCellStyle.ForeColor = Color.Black;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal memuat daftar buku: \n" + ex.Message, "Error Database");
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            FrmLogin.CurrentUserNIS = null;
            this.Close();
            new FrmLogin().Show();
        }

        private void btnCari_Click(object sender, EventArgs e)
        {
            string cari = txtCari.Text.Trim();
            LoadDaftarBuku(cari);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            LoadDaftarBuku();
        }

        private void btnPeminjaman_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (FrmPeminjaman frm = new FrmPeminjaman(FrmLogin.CurrentUserNIS))
            {
                frm.ShowDialog();
            }

            this.Show();
            LoadDaftarBuku();

        }

        private void btnPengembalian_Click(object sender, EventArgs e)
        {
            this.Hide();

            using (FrmPengembalian frm = new FrmPengembalian(FrmLogin.CurrentUserNIS))
            {
                frm.ShowDialog();
            }

            this.Show();
            LoadDaftarBuku();
        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
            txtCari.Clear();
            txtCari.Focus();
            LoadDaftarBuku();
        }
    }
}
