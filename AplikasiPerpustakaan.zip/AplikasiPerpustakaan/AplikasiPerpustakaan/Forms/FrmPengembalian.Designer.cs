﻿namespace AplikasiPerpustakaan.Forms
{
    partial class FrmPengembalian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPengembalian));
            pnlHeader = new Panel();
            btnBack = new Button();
            pictureBox1 = new PictureBox();
            lblPengembalian = new Label();
            pnlContent = new Panel();
            lblIntruksi = new Label();
            btnKembalikan = new Button();
            button2 = new Button();
            btnCari = new Button();
            txtCari = new TextBox();
            lblCari = new Label();
            dgvPeminjamanSaya = new DataGridView();
            lblWelcome = new Label();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPeminjamanSaya).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.Navy;
            pnlHeader.Controls.Add(btnBack);
            pnlHeader.Controls.Add(pictureBox1);
            pnlHeader.Controls.Add(lblPengembalian);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(732, 80);
            pnlHeader.TabIndex = 0;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.DeepSkyBlue;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = SystemColors.Control;
            btnBack.Location = new Point(606, 28);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(94, 30);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // lblPengembalian
            // 
            lblPengembalian.AutoSize = true;
            lblPengembalian.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPengembalian.ForeColor = Color.White;
            lblPengembalian.Location = new Point(96, 20);
            lblPengembalian.Name = "lblPengembalian";
            lblPengembalian.Size = new Size(203, 38);
            lblPengembalian.TabIndex = 1;
            lblPengembalian.Text = "Pengembalian";
            // 
            // pnlContent
            // 
            pnlContent.Controls.Add(lblIntruksi);
            pnlContent.Controls.Add(btnKembalikan);
            pnlContent.Controls.Add(button2);
            pnlContent.Controls.Add(btnCari);
            pnlContent.Controls.Add(txtCari);
            pnlContent.Controls.Add(lblCari);
            pnlContent.Controls.Add(dgvPeminjamanSaya);
            pnlContent.Controls.Add(lblWelcome);
            pnlContent.Dock = DockStyle.Fill;
            pnlContent.Location = new Point(0, 80);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(732, 342);
            pnlContent.TabIndex = 1;
            // 
            // lblIntruksi
            // 
            lblIntruksi.AutoSize = true;
            lblIntruksi.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblIntruksi.ForeColor = Color.DarkBlue;
            lblIntruksi.Location = new Point(56, 241);
            lblIntruksi.Margin = new Padding(3, 5, 3, 5);
            lblIntruksi.Name = "lblIntruksi";
            lblIntruksi.Size = new Size(291, 23);
            lblIntruksi.TabIndex = 20;
            lblIntruksi.Text = "Pilih satu baris lalu klik kembalikan";
            // 
            // btnKembalikan
            // 
            btnKembalikan.BackColor = Color.LightBlue;
            btnKembalikan.FlatAppearance.BorderSize = 0;
            btnKembalikan.FlatStyle = FlatStyle.Flat;
            btnKembalikan.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKembalikan.Location = new Point(56, 272);
            btnKembalikan.Name = "btnKembalikan";
            btnKembalikan.Size = new Size(112, 37);
            btnKembalikan.TabIndex = 19;
            btnKembalikan.Text = "Kembalikan";
            btnKembalikan.UseVisualStyleBackColor = false;
            btnKembalikan.Click += btnKembalikan_Click;
            // 
            // button2
            // 
            button2.Location = new Point(595, 48);
            button2.Name = "button2";
            button2.Size = new Size(66, 29);
            button2.TabIndex = 18;
            button2.Text = "Refresh";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnCari
            // 
            btnCari.Location = new Point(534, 48);
            btnCari.Name = "btnCari";
            btnCari.Size = new Size(55, 29);
            btnCari.TabIndex = 17;
            btnCari.Text = "Cari";
            btnCari.UseVisualStyleBackColor = true;
            btnCari.Click += btnCari_Click;
            // 
            // txtCari
            // 
            txtCari.Location = new Point(98, 50);
            txtCari.Name = "txtCari";
            txtCari.Size = new Size(430, 27);
            txtCari.TabIndex = 16;
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCari.Location = new Point(56, 51);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(40, 23);
            lblCari.TabIndex = 15;
            lblCari.Text = "Cari";
            lblCari.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // dgvPeminjamanSaya
            // 
            dgvPeminjamanSaya.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPeminjamanSaya.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPeminjamanSaya.Location = new Point(56, 83);
            dgvPeminjamanSaya.Name = "dgvPeminjamanSaya";
            dgvPeminjamanSaya.ReadOnly = true;
            dgvPeminjamanSaya.RowHeadersWidth = 51;
            dgvPeminjamanSaya.Size = new Size(604, 150);
            dgvPeminjamanSaya.TabIndex = 1;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.BackColor = Color.Transparent;
            lblWelcome.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcome.Location = new Point(56, 13);
            lblWelcome.Margin = new Padding(3);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(0, 31);
            lblWelcome.TabIndex = 0;
            // 
            // FrmPengembalian
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(732, 422);
            Controls.Add(pnlContent);
            Controls.Add(pnlHeader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmPengembalian";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pengembalian";
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlContent.ResumeLayout(false);
            pnlContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPeminjamanSaya).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Panel pnlContent;
        private Label lblPengembalian;
        private Button btnBack;
        private PictureBox pictureBox1;
        private DataGridView dgvPeminjamanSaya;
        private Label lblWelcome;
        private Button button2;
        private Button btnCari;
        private TextBox txtCari;
        private Label lblCari;
        private Label lblIntruksi;
        private Button btnKembalikan;
    }
}