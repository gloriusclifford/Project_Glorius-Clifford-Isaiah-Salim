<?php
include "config.php";

$id = $_POST['id'];
$nama = $_POST['nama_anggota'];
$jabatan = $_POST['jabatan'];
$partai = $_POST['partai'];
$gaji = $_POST['gaji_pokok'];
$rumah = $_POST['tunjangan_rumah'];
$jab = $_POST['tunjangan_jabatan'];
$trans = $_POST['tunjangan_transportasi'];

$query = "UPDATE gajidpr SET
            nama_anggota='$nama',
            jabatan='$jabatan',
            partai='$partai',
            gaji_pokok='$gaji',
            tunjangan_rumah='$rumah',
            tunjangan_jabatan='$jab',
            tunjangan_transportasi='$trans'
          WHERE id='$id'";

mysqli_query($koneksi, $query);

header("Location: index.php");
?>
