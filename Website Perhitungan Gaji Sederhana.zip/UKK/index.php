<?php include "config.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Gaji DPR</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body class="container py-4">

<h2>Data Gaji DPR</h2>

<a href="create.php" class="btn btn-primary mb-3">Tambah Data</a>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Partai</th>
            <th>Gaji Pokok</th>
            <th>Tunjangan Rumah</th>
            <th>Tunjangan Jabatan</th>
            <th>Tunjangan Transportasi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>

<?php
$query = mysqli_query($koneksi, "SELECT * FROM gajidpr");

while ($row = mysqli_fetch_assoc($query)) {
?>
        <tr>
            <td><?= $row['nama_anggota'] ?></td>
            <td><?= $row['jabatan'] ?></td>
            <td><?= $row['partai'] ?></td>
            <td>Rp. <?= number_format($row['gaji_pokok']) ?></td>
            <td>Rp. <?= number_format($row['tunjangan_rumah']) ?></td>
            <td>Rp. <?= number_format($row['tunjangan_jabatan']) ?></td>
            <td>Rp. <?= number_format($row['tunjangan_transportasi']) ?></td>
            <td>
                <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data?')">Hapus</a>
            </td>
        </tr>
<?php } ?>

    </tbody>
</table>

</body>
</html>
