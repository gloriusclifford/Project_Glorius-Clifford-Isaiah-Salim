-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2025 at 04:51 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uprakxi`
--

-- --------------------------------------------------------

--
-- Table structure for table `gajidpr`
--

CREATE TABLE `gajidpr` (
  `id` int(11) NOT NULL,
  `nama_anggota` varchar(250) NOT NULL,
  `jabatan` varchar(30) NOT NULL,
  `partai` varchar(30) NOT NULL,
  `gaji_pokok` decimal(12,2) NOT NULL,
  `tunjangan_rumah` decimal(12,2) NOT NULL,
  `tunjangan_jabatan` decimal(12,2) NOT NULL,
  `tunjangan_transportasi` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gajidpr`
--

INSERT INTO `gajidpr` (`id`, `nama_anggota`, `jabatan`, `partai`, `gaji_pokok`, `tunjangan_rumah`, `tunjangan_jabatan`, `tunjangan_transportasi`) VALUES
(16, 'Alexander orly Hutahaean', 'wakil ketua', 'partai golkar', 1000000000.00, 1000000000.00, 2000000000.00, 2000000000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gajidpr`
--
ALTER TABLE `gajidpr`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gajidpr`
--
ALTER TABLE `gajidpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
