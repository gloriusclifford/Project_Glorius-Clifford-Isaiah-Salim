<?php
include "config.php";
$nama = $_POST['nama_anggota'];
$jabatan = $_POST['jabatan'];
$partai = $_POST['partai'];
$gaji = $_POST['gaji_pokok'];
$rumah = $_POST['tunjangan_rumah'];
$jab = $_POST['tunjangan_jabatan'];
$trans = $_POST['tunjangan_transportasi'];


mysqli_query($koneksi, "INSERT INTO gajidpr VALUES(
    '',
    '$nama',
    '$jabatan',
    '$partai',
    '$gaji',
    '$rumah',
    '$jab',
    '$trans'
)");

header("Location: index.php");
?>