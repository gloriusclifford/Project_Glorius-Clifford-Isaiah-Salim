<?php
include "config.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data Gaji DPR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    
<h2>Tambah Data Gaji DPR</h2>

<form action="store.php" method="POST" id="form">
    <div class="mb-3">
        <label>Nama Anggota</label>
        <input type="text" name="nama_anggota" class="form-control" required>
    </div>
    
    <div class="mb-3">
        <label>Jabatan</label>
        <input type="text" name="jabatan" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Partai</label>
        <input type="text" name="partai" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Gaji Pokok</label>
        <input type="text" class="form-control currency" data-target="gaji_pokok" placeholder="Rp 0" required>
        <input type="hidden" name="gaji_pokok" id="gaji_pokok">
    </div>

    <div class="mb-3">
        <label>Tunjangan Rumah</label>
        <input type="text" class="form-control currency" data-target="tunjangan_rumah" placeholder="Rp 0" required>
        <input type="hidden" name="tunjangan_rumah" id="tunjangan_rumah">
    </div>

    <div class="mb-3">
        <label>Tunjangan Jabatan</label>
        <input type="text" class="form-control currency" data-target="tunjangan_jabatan" placeholder="Rp 0" required>
        <input type="hidden" name="tunjangan_jabatan" id="tunjangan_jabatan">
    </div>

    <div class="mb-3">
        <label>Tunjangan Transportasi</label>
        <input type="text" class="form-control currency" data-target="tunjangan_transportasi" placeholder="Rp 0" required>
        <input type="hidden" name="tunjangan_transportasi" id="tunjangan_transportasi">
    </div>

    <button class="btn btn-success">Simpan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
</form>
<script>
  
  function formatRupiahFromDigits(digits) {
    if (!digits) return '';
    return 'Rp ' + digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  document.querySelectorAll('.currency').forEach(function(input){
    const targetId = input.dataset.target;
    const hidden = document.getElementById(targetId);


    if (hidden && hidden.value) {
      input.value = formatRupiahFromDigits(hidden.value.toString());
    }

    input.addEventListener('input', function(){
    
      const digits = input.value.replace(/\D/g, '');

      input.value = digits ? formatRupiahFromDigits(digits) : '';

      if (hidden) hidden.value = digits;
      
      input.setSelectionRange(input.value.length, input.value.length);
    });
  });


  document.getElementById('form').addEventListener('submit', function(){
    document.querySelectorAll('.currency').forEach(function(input){
      const targetId = input.dataset.target;
      const hidden = document.getElementById(targetId);
      if (hidden) hidden.value = (input.value || '').replace(/\D/g, '');
    });
  });
</script>

</body>
</html>